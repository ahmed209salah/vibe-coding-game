import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { useFlightSimulator } from "../lib/stores/useFlightSimulator";

export function Lighting() {
  const lightRef = useRef<THREE.DirectionalLight>(null);
  const { position } = useFlightSimulator();
  
  // Update the light to follow the player
  useFrame(() => {
    if (lightRef.current) {
      lightRef.current.position.set(
        position.x + 50,
        position.y + 100,
        position.z + 50
      );
      lightRef.current.target.position.copy(position);
      lightRef.current.target.updateMatrixWorld();
    }
  });
  
  return (
    <>
      {/* Main directional light (sun) */}
      <directionalLight
        ref={lightRef}
        intensity={1.5}
        color="#fdfbd3"
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
        shadow-camera-far={3000}
        shadow-camera-left={-1000}
        shadow-camera-right={1000}
        shadow-camera-top={1000}
        shadow-camera-bottom={-1000}
        shadow-bias={-0.001}
      >
        {/* This is required to make the target work */}
        <object3D position={[0, 0, 0]} />
      </directionalLight>
      
      {/* Ambient light for general illumination */}
      <ambientLight intensity={0.5} />
      
      {/* Hemisphere light to better simulate sky and ground reflection */}
      <hemisphereLight 
        intensity={0.3} 
        color="#87CEEB" 
        groundColor="#8B4513" 
      />
    </>
  );
}
