import { useRef, useState, useEffect } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Box, Html } from "@react-three/drei";
import { useFlightSimulator } from "../lib/stores/useFlightSimulator";

export function Aircraft() {
  const aircraftRef = useRef<THREE.Group>(null);
  const { 
    position, 
    rotation, 
    playerName, 
    playerId, 
    playerColor, 
    players 
  } = useFlightSimulator();
  
  // Previous values for smoother transitions
  const prevPosition = useRef(new THREE.Vector3(0, 100, 0));
  const prevRotation = useRef(new THREE.Euler(0, 0, 0));
  
  // Update aircraft position and rotation each frame with smoother transitions
  useFrame(() => {
    if (aircraftRef.current) {
      // Update position and rotation from state with smoothing
      // This creates visual smoothness without affecting actual physics
      aircraftRef.current.position.set(
        prevPosition.current.x + (position.x - prevPosition.current.x) * 0.2,
        prevPosition.current.y + (position.y - prevPosition.current.y) * 0.2,
        prevPosition.current.z + (position.z - prevPosition.current.z) * 0.2
      );
      
      aircraftRef.current.rotation.set(
        prevRotation.current.x + (rotation.x - prevRotation.current.x) * 0.2,
        prevRotation.current.y + (rotation.y - prevRotation.current.y) * 0.2,
        prevRotation.current.z + (rotation.z - prevRotation.current.z) * 0.2
      );
      
      // Update previous values for next frame
      prevPosition.current.copy(aircraftRef.current.position);
      prevRotation.current.copy(aircraftRef.current.rotation);
      
      // Log position every few seconds for debugging
      if (Math.random() < 0.01) {
        console.log("Aircraft position:", position.toArray());
        console.log("Aircraft rotation:", {
          x: rotation.x.toFixed(2),
          y: rotation.y.toFixed(2),
          z: rotation.z.toFixed(2)
        });
      }
    }
  });

  return (
    <group>
      {/* Player Aircraft */}
      <group ref={aircraftRef}>
        {/* Fuselage */}
        <Box
          args={[2, 1, 6]}
          position={[0, 0, 0]}
        >
          <meshStandardMaterial 
            color={new THREE.Color(playerColor)} 
            metalness={0.8}
            roughness={0.2}
          />
        </Box>
        
        {/* Wings */}
        <Box
          args={[12, 0.2, 2]}
          position={[0, 0, 0]}
        >
          <meshStandardMaterial 
            color={new THREE.Color(playerColor)} 
            metalness={0.8}
            roughness={0.2}
          />
        </Box>
        
        {/* Tail Wing */}
        <Box
          args={[4, 0.2, 1]}
          position={[0, 0, -3]}
        >
          <meshStandardMaterial color={new THREE.Color(playerColor)} />
        </Box>
        
        {/* Vertical Stabilizer */}
        <Box
          args={[0.2, 1.6, 1.6]}
          position={[0, 0.8, -3]}
        >
          <meshStandardMaterial color={new THREE.Color(playerColor)} />
        </Box>
        
        {/* Player name tag */}
        <Html
          position={[0, 1, 0]}
          center
          className="player-tag"
          distanceFactor={15}
        >
          {playerName}
        </Html>
      </group>
      
      {/* Other players' aircraft */}
      {Array.from(players).map(([id, player]) => {
        // Don't render the local player twice
        if (id === playerId) return null;
        
        return (
          <group 
            key={id}
            position={[
              player.position.x,
              player.position.y,
              player.position.z
            ]}
            rotation={[
              player.rotation.x,
              player.rotation.y,
              player.rotation.z
            ]}
          >
            {/* Fuselage */}
            <Box
              args={[1, 0.5, 3]}
              position={[0, 0, 0]}
            >
              <meshStandardMaterial color={new THREE.Color(player.color)} />
            </Box>
            
            {/* Wings */}
            <Box
              args={[6, 0.1, 1]}
              position={[0, 0, 0]}
            >
              <meshStandardMaterial color={new THREE.Color(player.color)} />
            </Box>
            
            {/* Tail Wing */}
            <Box
              args={[2, 0.1, 0.5]}
              position={[0, 0, -1.5]}
            >
              <meshStandardMaterial color={new THREE.Color(player.color)} />
            </Box>
            
            {/* Vertical Stabilizer */}
            <Box
              args={[0.1, 0.8, 0.8]}
              position={[0, 0.4, -1.5]}
            >
              <meshStandardMaterial color={new THREE.Color(player.color)} />
            </Box>
            
            {/* Player name tag */}
            <Html
              position={[0, 1, 0]}
              center
              className="player-tag"
              distanceFactor={15}
            >
              {player.name}
            </Html>
          </group>
        );
      })}
    </group>
  );
}
