import { useEffect } from "react";
import { useFlightSimulator } from "../lib/stores/useFlightSimulator";
import { initializeSocket, closeSocket } from "../lib/socket";

export function MultiplayerManager() {
  const { 
    phase, 
    singlePlayer,
    playerId
  } = useFlightSimulator();
  
  // Initialize socket connection for multiplayer
  useEffect(() => {
    if (!singlePlayer && phase === 'playing' && playerId) {
      initializeSocket();
      
      // Clean up on unmount
      return () => {
        closeSocket();
      };
    }
  }, [singlePlayer, phase, playerId]);
  
  // This component doesn't render anything, it just manages multiplayer
  return null;
}
