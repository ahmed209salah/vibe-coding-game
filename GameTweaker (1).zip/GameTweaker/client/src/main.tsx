import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Wait for document to be fully loaded before mounting
document.addEventListener('DOMContentLoaded', () => {
  // Hide the traditional HTML elements
  const elements = [
    'loader', 'main-menu', 'create-room-screen', 
    'join-room-screen', 'info', 'room-info', 'exit-game-btn'
  ];
  
  elements.forEach(id => {
    const element = document.getElementById(id);
    if (element) {
      element.style.display = 'none';
    }
  });

  // Mount the React application
  createRoot(document.getElementById("root")!).render(<App />);
});
