
import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import cors from 'cors';

const app = express();
const server = createServer(app);

const io = new Server(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

// Store active rooms
const mainRoom = {
  code: "main",
  players: new Map()
};

io.on("connection", (socket) => {
  socket.on("joinRoom", ({ name }) => {
    const playerColor = Math.random() * 0xffffff;
    const player = {
      id: socket.id,
      name,
      color: playerColor,
      position: { x: 0, y: 100, z: 0 },
      rotation: { x: 0, y: 0, z: 0 },
      velocity: 30
    };
    
    mainRoom.players.set(socket.id, player);
    socket.join("main");
    
    socket.emit("roomJoined", {
      roomCode: "main",
      playerId: socket.id,
      playerName: name,
      playerColor,
      players: Array.from(mainRoom.players.values())
    });
    
    socket.broadcast.to("main").emit("playerJoined", player);
  });

  socket.on("disconnect", () => {
    if (mainRoom.players.has(socket.id)) {
      mainRoom.players.delete(socket.id);
      io.to("main").emit("playerLeft", { id: socket.id });
    }
  });

  socket.on("updatePlayer", (data) => {
    if (mainRoom.players.has(socket.id)) {
      const updatedData = { id: socket.id, ...data };
      socket.broadcast.to("main").emit("playerUpdated", updatedData);
    }
  });
});

server.listen(5000, '0.0.0.0', () => {
  console.log('Server running at http://0.0.0.0:5000');
});
