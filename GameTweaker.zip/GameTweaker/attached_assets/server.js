// Flight Simulator Multiplayer Server
const http = require('http');
const { Server } = require('socket.io');
const PORT = process.env.PORT || 3000;

// Create HTTP server
const server = http.createServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end('Flight Simulator Server Running\n');
});

// Initialize Socket.IO
const io = new Server(server, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    }
});

// Game state
const rooms = new Map();
const MAX_PLAYERS_PER_ROOM = 10;
const PLAYER_COLORS = [
    0xff0000, // red
    0x00ff00, // green
    0x0000ff, // blue
    0xffff00, // yellow
    0xff00ff, // magenta
    0x00ffff, // cyan
    0xff8000, // orange
    0x8000ff, // purple
    0x0080ff, // light blue
    0x80ff00  // lime
];

// Generate a random 6-digit room code
function generateRoomCode() {
    return Math.floor(100000 + Math.random() * 900000).toString();
}

// Handle WebSocket connections
io.on('connection', (socket) => {
    console.log(`New connection: ${socket.id}`);
    let currentRoom = null;
    let playerName = '';

    // Create a new room
    socket.on('createRoom', (name) => {
        playerName = name || `Player_${socket.id.substr(0, 5)}`;
        const roomCode = generateRoomCode();
        
        // Create the room with this player as the first member
        rooms.set(roomCode, {
            players: new Map([[socket.id, {
                id: socket.id,
                name: playerName,
                position: { x: 0, y: 2, z: 0 },
                rotation: { x: 0, y: 0, z: 0 },
                color: PLAYER_COLORS[0],
                velocity: 0
            }]]),
            createdAt: Date.now()
        });
        
        // Join the Socket.IO room
        socket.join(roomCode);
        currentRoom = roomCode;
        
        console.log(`Room ${roomCode} created by ${playerName}`);
        
        // Send room information to client
        socket.emit('roomCreated', {
            roomCode,
            playerId: socket.id,
            playerName,
            playerColor: PLAYER_COLORS[0]
        });
        
        // Broadcast player info to all clients in the room
        updatePlayerCount(roomCode);
    });

    // Join an existing room
    socket.on('joinRoom', ({ roomCode, name }) => {
        roomCode = roomCode.toString();
        playerName = name || `Player_${socket.id.substr(0, 5)}`;
        
        // Validate that the room exists
        if (!rooms.has(roomCode)) {
            socket.emit('error', { message: 'Room does not exist' });
            return;
        }
        
        const room = rooms.get(roomCode);
        
        // Check if room is full
        if (room.players.size >= MAX_PLAYERS_PER_ROOM) {
            socket.emit('error', { message: 'Room is full' });
            return;
        }
        
        // Assign a unique color for this player
        const colorIndex = room.players.size % PLAYER_COLORS.length;
        const playerColor = PLAYER_COLORS[colorIndex];
        
        // Add player to the room
        room.players.set(socket.id, {
            id: socket.id,
            name: playerName,
            position: { x: 0, y: 2, z: 0 },
            rotation: { x: 0, y: 0, z: 0 },
            color: playerColor,
            velocity: 0
        });
        
        // Join the Socket.IO room
        socket.join(roomCode);
        currentRoom = roomCode;
        
        console.log(`${playerName} joined room ${roomCode}`);
        
        // Send room information to the new player
        socket.emit('roomJoined', {
            roomCode,
            playerId: socket.id,
            playerName,
            playerColor,
            // Send existing players data
            players: Array.from(room.players.entries()).map(([id, player]) => ({
                id,
                name: player.name,
                position: player.position,
                rotation: player.rotation,
                color: player.color,
                velocity: player.velocity
            }))
        });
        
        // Notify other players about the new player
        socket.to(roomCode).emit('playerJoined', {
            id: socket.id,
            name: playerName,
            position: { x: 0, y: 2, z: 0 },
            rotation: { x: 0, y: 0, z: 0 },
            color: playerColor,
            velocity: 0
        });
        
        // Update player count for everyone
        updatePlayerCount(roomCode);
    });

    // Update player state (position, rotation, etc.)
    socket.on('updatePlayer', (data) => {
        if (!currentRoom || !rooms.has(currentRoom)) return;
        
        const room = rooms.get(currentRoom);
        const player = room.players.get(socket.id);
        
        if (!player) return;
        
        // Update player state
        if (data.position) player.position = data.position;
        if (data.rotation) player.rotation = data.rotation;
        if (data.velocity !== undefined) player.velocity = data.velocity;
        
        // Broadcast to other players in the room
        socket.to(currentRoom).emit('playerUpdated', {
            id: socket.id,
            ...data
        });
    });

    // Handle player disconnect
    socket.on('disconnect', () => {
        console.log(`Disconnected: ${socket.id}`);
        handlePlayerLeave();
    });

    // Handle explicit room leave
    socket.on('leaveRoom', () => {
        console.log(`${playerName} left room ${currentRoom}`);
        handlePlayerLeave();
    });

    // Helper function to handle player leaving
    function handlePlayerLeave() {
        if (currentRoom && rooms.has(currentRoom)) {
            const room = rooms.get(currentRoom);
            
            // Remove the player from the room
            room.players.delete(socket.id);
            
            // Notify other players
            socket.to(currentRoom).emit('playerLeft', { id: socket.id });
            
            // If the room is empty, delete it
            if (room.players.size === 0) {
                console.log(`Room ${currentRoom} is empty, deleting`);
                rooms.delete(currentRoom);
            } else {
                // Update player count
                updatePlayerCount(currentRoom);
            }
            
            // Leave the socket.io room
            socket.leave(currentRoom);
            currentRoom = null;
        }
    }

    // Helper function to broadcast player count update
    function updatePlayerCount(roomCode) {
        if (!rooms.has(roomCode)) return;
        
        const playerCount = rooms.get(roomCode).players.size;
        io.to(roomCode).emit('playerCount', { 
            count: playerCount, 
            maxPlayers: MAX_PLAYERS_PER_ROOM 
        });
    }
});

// Clean up inactive rooms (every hour)
setInterval(() => {
    const now = Date.now();
    for (const [roomCode, room] of rooms.entries()) {
        // Remove rooms older than 3 hours
        if (now - room.createdAt > 3 * 60 * 60 * 1000) {
            console.log(`Removing inactive room ${roomCode}`);
            rooms.delete(roomCode);
        }
    }
}, 60 * 60 * 1000);

// Start server
server.listen(PORT, () => {
    console.log(`Flight Simulator server running on port ${PORT}`);
});

