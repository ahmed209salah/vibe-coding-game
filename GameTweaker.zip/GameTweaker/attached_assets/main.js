// Game states
const GameState = {
    MENU: 'menu',
    PLAYING: 'playing',
    LOADING: 'loading'
};

// Multiplayer states
const MultiplayerState = {
    DISCONNECTED: 'disconnected',
    CONNECTING: 'connecting',
    CONNECTED: 'connected',
    ERROR: 'error'
};

// Set up core variables
let scene, camera, renderer, airplane, clock;
let cameraOffset = new THREE.Vector3(0, 2, 5);
const WORLD_SIZE = 15; // 15x15 world
let socket = null;
let currentState = GameState.MENU;
let multiplayerState = MultiplayerState.DISCONNECTED;
let isMultiplayer = false;
let playerData = null;
let otherPlayers = new Map(); // Map of player ID to player object
let playerNameLabels = new Map(); // Map of player ID to DOM elements for names
let currentRoom = null;
let playerUpdateInterval = null;
let updateRate = 50; // ms between position updates to server
let smoothingFactor = 0.1; // For smooth movement interpolation

// DOM elements (cached for performance)
const menuElements = {
    mainMenu: document.getElementById('main-menu'),
    multiplayerMenu: document.getElementById('multiplayer-menu'),
    roomInfo: document.getElementById('room-info'),
    gameInfo: document.getElementById('info'),
    gameUI: document.getElementById('game-ui'),
    currentRoomDisplay: document.getElementById('current-room'),
    playerCountDisplay: document.getElementById('player-count'),
    multiplayerStatus: document.getElementById('multiplayer-status'),
    roomNumberInput: document.getElementById('room-number'),
    playerNameInput: document.getElementById('player-name')
};

// Initialize the application
function init() {
    // Set up menu event listeners
    setupMenuListeners();
    
    // Create a clock for consistent animation timing
    clock = new THREE.Clock();
    
    // Handle window resizing
    window.addEventListener('resize', onWindowResize);
    
    // Start in menu state
    currentState = GameState.MENU;
}

// Initialize the game scene
function initGame(multiplayerMode = false) {
    // Update state
    currentState = GameState.PLAYING;
    isMultiplayer = multiplayerMode;
    
    // Create scene (background will be set after WebGL diagnostics)
    scene = new THREE.Scene();
    
    // WebGL diagnostic script
    console.log("Running WebGL diagnostics and initialization...");
    
    // Custom context creation to ensure proper initialization
    function createWebGLContext(canvas, attributes) {
        // Try to create WebGL2 context first (better performance and features)
        let gl = null;
        try {
            gl = canvas.getContext('webgl2', attributes);
            if (gl) {
                console.log("Successfully created WebGL2 context");
                return gl;
            }
        } catch (e) {
            console.warn("WebGL2 context creation failed:", e);
        }
        
        // Fall back to WebGL1
        try {
            gl = canvas.getContext('webgl', attributes) || 
                 canvas.getContext('experimental-webgl', attributes);
            if (gl) {
                console.log("Successfully created WebGL1 context");
                return gl;
            }
        } catch (e) {
            console.warn("WebGL1 context creation failed:", e);
        }
        
        console.error("Failed to create any WebGL context");
        return null;
    }
    
    // Immediate validation to detect context issues early
    function validateWebGLContext(gl) {
        if (!gl) return false;
        
        // Check if context is lost
        if (gl.isContextLost()) {
            console.error("WebGL context is already lost during initialization");
            return false;
        }
        
        // Try to clear the context (catches some initialization issues)
        try {
            gl.clearColor(0.53, 0.81, 0.92, 1.0);
            gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
            gl.flush();
            
            // Force synchronization - helps with driver issues
            gl.finish();
            
            return true;
        } catch (e) {
            console.error("WebGL validation failed:", e);
            return false;
        }
    }
    
    // Check WebGL support and capabilities
    function checkWebGLCapabilities() {
        const diagnostics = {
            webglSupported: false,
            webgl2Supported: false,
            vendor: 'unknown',
            renderer: 'unknown',
            unmaskedVendor: 'unknown',
            unmaskedRenderer: 'unknown',
            maxTextureSize: 0,
            maxViewportDims: [0, 0],
            antialiasingSupported: false,
            extensions: []
        };
        
        try {
            // Try to create a WebGL context
            const canvas = document.createElement('canvas');
            
            // First check WebGL1
            const gl1 = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
            if (gl1) {
                diagnostics.webglSupported = true;
                diagnostics.vendor = gl1.getParameter(gl1.VENDOR);
                diagnostics.renderer = gl1.getParameter(gl1.RENDERER);
                
                // Get unmasked info if available
                const debugInfo = gl1.getExtension('WEBGL_debug_renderer_info');
                if (debugInfo) {
                    diagnostics.unmaskedVendor = gl1.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL);
                    diagnostics.unmaskedRenderer = gl1.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL);
                }
                
                // Check capabilities
                diagnostics.maxTextureSize = gl1.getParameter(gl1.MAX_TEXTURE_SIZE);
                diagnostics.maxViewportDims = gl1.getParameter(gl1.MAX_VIEWPORT_DIMS);
                
                // Check for antialiasing support
                diagnostics.antialiasingSupported = gl1.getContextAttributes().antialias;
                
                // List available extensions
                diagnostics.extensions = gl1.getSupportedExtensions() || [];
            }
            
            // Then check WebGL2
            const gl2 = canvas.getContext('webgl2');
            if (gl2) {
                diagnostics.webgl2Supported = true;
            }
            
            // Check for framebuffer completeness
            if (gl1) {
                try {
                    // Create and check a simple framebuffer
                    const framebuffer = gl1.createFramebuffer();
                    gl1.bindFramebuffer(gl1.FRAMEBUFFER, framebuffer);
                    const status = gl1.checkFramebufferStatus(gl1.FRAMEBUFFER);
                    diagnostics.framebufferComplete = (status === gl1.FRAMEBUFFER_COMPLETE);
                    
                    if (!diagnostics.framebufferComplete) {
                        console.warn("Framebuffer initialization may have issues:", status);
                    }
                    
                    // Clean up
                    gl1.bindFramebuffer(gl1.FRAMEBUFFER, null);
                    gl1.deleteFramebuffer(framebuffer);
                } catch (e) {
                    console.warn("Framebuffer test failed:", e);
                }
            }
            
        } catch (error) {
            console.error("Error during WebGL capability detection:", error);
        }
        
        return diagnostics;
    }
    
    // Run the diagnostics
    const webglDiagnostics = checkWebGLCapabilities();
    console.log("WebGL Diagnostics:", webglDiagnostics);
    
    // Create a warning if limited WebGL support is detected
    function createWebGLWarning(message) {
        const warning = document.createElement('div');
        warning.style.position = 'fixed';
        warning.style.bottom = '10px';
        warning.style.left = '10px';
        warning.style.backgroundColor = 'rgba(255, 0, 0, 0.8)';
        warning.style.color = 'white';
        warning.style.padding = '10px';
        warning.style.borderRadius = '5px';
        warning.style.zIndex = '1000';
        warning.style.fontSize = '14px';
        warning.style.maxWidth = '400px';
        warning.innerHTML = message;
        document.body.appendChild(warning);
        
        // Add a close button
        const closeBtn = document.createElement('button');
        closeBtn.textContent = 'Close';
        closeBtn.style.marginLeft = '10px';
        closeBtn.style.padding = '3px 8px';
        closeBtn.onclick = function() { warning.remove(); };
        warning.appendChild(closeBtn);
    }
    
    // Configure renderer settings based on diagnostics
    let rendererSettings = {};
    
    if (!webglDiagnostics.webglSupported) {
        createWebGLWarning('WebGL is not supported by your browser. The game may not work properly.');
        // Use most basic settings as fallback
        rendererSettings = {
            antialias: false,
            alpha: true,
            precision: 'lowp',
            preserveDrawingBuffer: true
        };
    } else {
        // Create a test canvas to validate context creation before using THREE.js
        const testCanvas = document.createElement('canvas');
        testCanvas.width = 128;
        testCanvas.height = 128;
        
        // Create attributes with conservative settings
        const testAttributes = {
            alpha: true,
            antialias: false,
            preserveDrawingBuffer: true,
            premultipliedAlpha: false,
            stencil: true,
            depth: true
        };
        
        // Get a test context
        const testGL = createWebGLContext(testCanvas, testAttributes);
        
        // Validate the test context
        if (testGL) {
            const isValid = validateWebGLContext(testGL);
            if (!isValid) {
                console.warn("Initial WebGL context validation failed - will use more conservative settings");
            }
            
            // For NVIDIA GPUs, perform additional early validation
            try {
                const debugInfo = testGL.getExtension('WEBGL_debug_renderer_info');
                if (debugInfo) {
                    const vendor = testGL.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL);
                    const renderer = testGL.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL);
                    
                    const isNvidia = vendor.toLowerCase().includes('nvidia');
                    const isRTX = renderer.toLowerCase().includes('rtx');
                    
                    if (isNvidia) {
                        console.log("NVIDIA GPU detected - applying early validation sequence");
                        
                        // Special sequence for NVIDIA GPUs to prevent black screen
                        // This helps initialize the driver properly
                        testGL.disable(testGL.DITHER);
                        testGL.pixelStorei(testGL.UNPACK_COLORSPACE_CONVERSION_WEBGL, testGL.NONE);
                        
                        // Clear with multiple passes
                        for (let i = 0; i < 3; i++) {
                            testGL.clearColor(0.53, 0.81, 0.92, 1.0);
                            testGL.clear(testGL.COLOR_BUFFER_BIT | testGL.DEPTH_BUFFER_BIT);
                            testGL.flush();
                            testGL.finish();
                        }
                        
                        if (isRTX) {
                            console.log("RTX GPU detected - applying enhanced initialization");
                            // Create temporary buffers to fully initialize the context
                            const tempBuffer = testGL.createBuffer();
                            testGL.bindBuffer(testGL.ARRAY_BUFFER, tempBuffer);
                            testGL.bufferData(testGL.ARRAY_BUFFER, new Float32Array([0, 0, 0, 1]), testGL.STATIC_DRAW);
                            testGL.deleteBuffer(tempBuffer);
                        }
                    }
                }
            } catch (e) {
                console.warn("Error during NVIDIA GPU early validation:", e);
            }
        }
        // Check for problematic GPU/drivers based on vendor
        const vendorLower = (webglDiagnostics.unmaskedVendor || webglDiagnostics.vendor).toLowerCase();
        const rendererLower = (webglDiagnostics.unmaskedRenderer || webglDiagnostics.renderer).toLowerCase();
        
        console.log(`GPU Vendor: ${vendorLower}, Renderer: ${rendererLower}`);
        
        if (vendorLower.includes('intel')) {
            console.log('Intel GPU detected, using conservative settings');
            // Intel GPUs sometimes have issues with certain WebGL features
            rendererSettings = {
                antialias: false,
                alpha: false,
                precision: 'mediump',
                powerPreference: 'default',
                preserveDrawingBuffer: true,
                stencil: false
            };
            createWebGLWarning('Intel GPU detected. If you experience rendering issues, try updating your graphics drivers.');
        } else if (vendorLower.includes('nvidia')) {
            console.log('NVIDIA GPU detected, using optimized settings for RTX/GTX series');
            
            // Check if we're dealing with an RTX series GPU
            const isRTXSeries = rendererLower.includes('rtx');
            const isNewerDriver = rendererLower.includes('opengl 4.5') || rendererLower.includes('opengl 4.6');
            const isMobileGPU = rendererLower.includes('mobile') || rendererLower.includes('max-q');
            
            console.log(`NVIDIA details: RTX: ${isRTXSeries}, Newer Driver: ${isNewerDriver}, Mobile: ${isMobileGPU}`);
            
            // NVIDIA GPUs need specific settings to prevent black screen issues
            // especially after driver updates on RTX series
            rendererSettings = {
                // Use antialiasing only if supported and not using RTX series 
                // (can cause issues with newer drivers)
                antialias: webglDiagnostics.antialiasingSupported && !isRTXSeries,
                
                // Alpha channel handling - important for proper buffer management
                alpha: true,
                
                // Conservative precision setting for stability
                // Lower precision is more stable on RTX but reduces quality
                precision: isRTXSeries ? 'mediump' : 'highp',
                
                // This is crucial for NVIDIA GPUs - preserveDrawingBuffer must be true
                // to prevent black screen after a few frames, especially on newer drivers
                preserveDrawingBuffer: true,
                
                // Use a balanced power setting for most GPUs
                // Mobile GPUs benefit from low-power mode to prevent thermal throttling
                powerPreference: isMobileGPU ? 'low-power' : 'default',
                
                // Prevent memory leaks and buffer management issues
                premultipliedAlpha: false,
                stencil: false,
                
                // Additional settings for RTX cards
                depth: true,
                
                // Fail if there are major performance issues - this helps identify problems early
                failIfMajorPerformanceCaveat: false
            };
            
            // Create a function to initialize WebGL context with explicit attributes
            // This helps ensure proper initialization on NVIDIA GPUs
            if (isRTXSeries) {
                console.log("Applying RTX-specific context creation");
                
                try {
                    // Create a test canvas with larger size for better initialization
                    const testCanvas = document.createElement('canvas');
                    testCanvas.width = 512; // Larger canvas for better initialization
                    testCanvas.height = 512;
                    
                    const contextAttributes = {
                        alpha: rendererSettings.alpha,
                        antialias: rendererSettings.antialias,
                        depth: rendererSettings.depth,
                        stencil: rendererSettings.stencil,
                        premultipliedAlpha: rendererSettings.premultipliedAlpha,
                        preserveDrawingBuffer: rendererSettings.preserveDrawingBuffer,
                        powerPreference: rendererSettings.powerPreference
                    };
                    
                    // Use custom context creation for better initialization
                    const gl = createWebGLContext(testCanvas, contextAttributes);
                    
                    if (gl && validateWebGLContext(gl)) {
                        console.log("Pre-initialized and validated WebGL context successful");
                        
                        // Enhanced initialization sequence for NVIDIA GPUs
                        const enhancedInit = function(gl) {
                            // Force a complete initialization of the WebGL pipeline
                            gl.clearColor(0.53, 0.81, 0.92, 1.0);
                            gl.clearDepth(1.0);
                            
                            // Enable/disable various features to ensure full driver initialization
                            gl.enable(gl.DEPTH_TEST);
                            gl.depthFunc(gl.LEQUAL);
                            gl.enable(gl.BLEND);
                            gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
                            
                            // Initialize quad coordinates (common pattern to kickstart rendering)
                            const vertices = new Float32Array([
                                -1.0, -1.0, 0.0,
                                 1.0, -1.0, 0.0,
                                -1.0,  1.0, 0.0,
                                 1.0,  1.0, 0.0
                            ]);
                            
                            // Create and initialize a buffer (forces driver to initialize buffer objects)
                            const buffer = gl.createBuffer();
                            gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
                            gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);
                            
                            // Clear multiple times with different clear masks
                            gl.clear(gl.COLOR_BUFFER_BIT);
                            gl.flush();
                            gl.clear(gl.DEPTH_BUFFER_BIT);
                            gl.flush();
                            gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
                            gl.flush();
                            gl.finish(); // Force command completion
                            
                            // Clean up
                            gl.bindBuffer(gl.ARRAY_BUFFER, null);
                            gl.deleteBuffer(buffer);
                            
                            // Disable features we enabled
                            gl.disable(gl.BLEND);
                            gl.disable(gl.DEPTH_TEST);
                            
                            return true;
                        
            
            // Show a specific warning for RTX users about potential black screen issues
            if (isRTXSeries && isNewerDriver) {
                createWebGLWarning(
                    'NVIDIA RTX GPU detected with newer drivers. If you experience rendering issues, ' +
                    'try enabling "Hardware-accelerated GPU scheduling" in Windows settings.'
                );
            }
        } else if (vendorLower.includes('amd') || vendorLower.includes('ati')) {
            // AMD/ATI settings
            rendererSettings = {
                antialias: webglDiagnostics.antialiasingSupported,
                alpha: false,
                precision: 'highp',
                powerPreference: 'high-performance',
                preserveDrawingBuffer: true
            };
        } else {
            // Default/unknown GPU
            rendererSettings = {
                antialias: false, // Start conservative
                alpha: true,
                precision: 'mediump',
                powerPreference: 'default',
                preserveDrawingBuffer: true
            };
        }
        
        // Additional warnings based on capabilities
        if (webglDiagnostics.maxTextureSize < 2048) {
            createWebGLWarning('Your GPU supports only small textures. Visual quality may be reduced.');
        }
    }
    
    console.log("Using renderer settings:", rendererSettings);
    
    // Create a more interesting background (gradient sky instead of flat color)
    // This can help diagnose if the issue is with the background rendering
    const skyColors = {
        topColor: new THREE.Color(0x0077ff),  // Deeper blue at top
        middleColor: new THREE.Color(0x87CEEB), // Sky blue in middle 
        bottomColor: new THREE.Color(0xFFFFFF)  // White at horizon
    };
    
    const skyMaterial = new THREE.ShaderMaterial({
        uniforms: {
            topColor: { value: skyColors.topColor },
            middleColor: { value: skyColors.middleColor },
            bottomColor: { value: skyColors.bottomColor },
            offset: { value: 33 },
            exponent: { value: 0.6 }
        },
        vertexShader: `
            varying vec3 vWorldPosition;
            void main() {
                vec4 worldPosition = modelMatrix * vec4(position, 1.0);
                vWorldPosition = worldPosition.xyz;
                gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
            }
        `,
        fragmentShader: `
            uniform vec3 topColor;
            uniform vec3 middleColor;
            uniform vec3 bottomColor;
            uniform float offset;
            uniform float exponent;
            varying vec3 vWorldPosition;
            void main() {
                float h = normalize(vWorldPosition + offset).y;
                float t = max(0.0, min(1.0, (h + 1.0) / 2.0));
                vec3 color;
                if (t < 0.5) {
                    color = mix(bottomColor, middleColor, t * 2.0);
                } else {
                    color = mix(middleColor, topColor, (t - 0.5) * 2.0);
                }
                gl_FragColor = vec4(color, 1.0);
            }
        `,
        side: THREE.BackSide
    });
    
    // Create and add sky dome to the scene
    const skySphere = new THREE.Mesh(
        new THREE.SphereGeometry(100, 32, 15),
        skyMaterial
    );
    scene.add(skySphere);
    
    // Fallback solid color background (just in case shaders don't work)
    scene.background = new THREE.Color(0x87CEEB);

    // We've already checked WebGL support above, no need for duplicate check

    console.log('Initializing WebGL renderer...');
    
    // Create rendering statistics object to monitor performance
    const stats = {
        frameCount: 0,
        startTime: performance.now(),
        lastFrameTime: 0,
        renders: 0,
        errors: 0,
        lastErrorTime: 0,
        earlyFrameValidated: false,  // Track if early frame validation has occurred
        initialRenderComplete: false // Track if initial render completed successfully
    };
    
    // Function to try creating a renderer with given settings
    function createRenderer(settings, name = "primary") {
        try {
            console.log(`Attempting to create ${name} renderer with settings:`, settings);
            const newRenderer = new THREE.WebGLRenderer(settings);
            
            // Check if we got a valid context
            if (!newRenderer.getContext()) {
                throw new Error("Renderer created, but context is null");
            }
            
            console.log(`Successfully created ${name} renderer`);
            return newRenderer;
        } catch (error) {
            console.warn(`Failed to create ${name} renderer:`, error);
            return null;
        }
    }
    
    // Try different renderer configurations in order of preference
    renderer = createRenderer(rendererSettings, "optimized") || 
              createRenderer({ 
                  antialias: false, 
                  alpha: true,
                  precision: 'lowp', 
                  powerPreference: 'default', 
                  preserveDrawingBuffer: true 
              }, "fallback") ||
              createRenderer({ 
                  antialias: false, 
                  alpha: true, 
                  precision: 'lowp'
              }, "minimal");
    
    if (!renderer) {
        // All renderer creation attempts failed
        console.error("All WebGL renderer creation attempts failed");
        const warning = document.createElement('div');
        warning.style.position = 'absolute';
        warning.style.top = '50%';
        warning.style.width = '100%';
        warning.style.textAlign = 'center';
        warning.innerHTML = 'WebGL initialization failed. Please check your browser settings, update your graphics drivers, or try a different browser.';
        document.getElementById('container').appendChild(warning);
        return;
    }
    
    // Add tracking to detect black screen issues
    renderer.userData = {
        ...stats,
        blackScreenDetected: false,
        recoveryAttempts: 0,
        framesSinceInit: 0,
        lastFrameSuccessful: false,
        validationHistory: [], // Track recent validation results
        frameValidationDone: false // Track if initial validation was completed
    };
    
    // Immediate validation of the renderer to prevent black screen issues
    console.log("Performing immediate renderer validation...");
    const validateRenderer = function() {
        try {
            const gl = renderer.getContext();
            if (!gl) {
                console.error("Unable to get WebGL context during validation");
                return false;
            }
            
            // Check for NVIDIA-specific optimizations
            const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
            let isNvidiaGPU = false;
            let isRTXSeries = false;
            
            if (debugInfo) {
                const vendor = gl.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL);
                const rendererInfo = gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL);
                isNvidiaGPU = vendor.toLowerCase().includes('nvidia');
                isRTXSeries = rendererInfo.toLowerCase().includes('rtx');
                
                console.log(`Validation - GPU detection: NVIDIA: ${isNvidiaGPU}, RTX: ${isRTXSeries}`);
            }
            
            // 1. Force complete multi-step buffer clearing
            console.log("Validation - Clearing buffers");
            
            // First clear with low-level WebGL commands
            gl.clearColor(0.53, 0.81, 0.92, 1.0); // Sky blue
            gl.clearDepth(1.0);
            gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
            gl.flush();
            
            // Then use THREE.js clear
            renderer.setClearColor(0x87CEEB, 1.0);
            renderer.clearColor();
            renderer.clearDepth();
            
            // For NVIDIA GPUs, extra clearing steps
            if (isNvidiaGPU) {
                // Scissor test to force buffer refresh
                gl.enable(gl.SCISSOR_TEST);
                
                // Clear in 4 quadrants to ensure full buffer refresh
                const width = renderer.domElement.width;
                const height = renderer.domElement.height;
                
                const sections = [
                    [0, 0, width/2, height/2],
                    [width/2, 0, width/2, height/2],
                    [0, height/2, width/2, height/2],
                    [width/2, height/2, width/2, height/2]
                ];
                
                for (const [x, y, w, h] of sections) {
                    gl.scissor(x, y, w, h);
                    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
                }
                
                // Reset scissor
                gl.scissor(0, 0, width, height);
                gl.disable(gl.SCISSOR_TEST);
                
                // Final clear
                gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
            }
            
            // 2. Create a minimal test scene for validation
            console.log("Validation - Creating test scene");
            const testScene = new THREE.Scene();
            testScene.background = new THREE.Color(0x87CEEB);
            
            // Simple red box
            const geometry = new THREE.BoxGeometry(1, 1, 1);
            const material = new THREE.MeshBasicMaterial({ color: 0xff0000 });
            const cube = new THREE.Mesh(geometry, material);
            testScene.add(cube);
            
            // Simple camera
            const camera = new THREE.PerspectiveCamera(75, renderer.domElement.width / renderer.domElement.height, 0.1, 10);
            camera.position.z = 5;
            
            // 3. Render the test scene
            console.log("Validation - Rendering test scene");
            renderer.render(testScene, camera);
            
            // 4. Ensure synchronization
            gl.flush();
            gl.finish(); // Force completion of all GL commands
            
            // 5. Check the result
            // Read a pixel from the center of the canvas
            console.log("Validation - Reading result pixel");
            const pixel = new Uint8Array(4);
            gl.readPixels(
                Math.floor(renderer.domElement.width / 2),
                Math.floor(renderer.domElement.height / 2),
                1, 1,
                gl.RGBA,
                gl.UNSIGNED_BYTE,
                pixel
            );
            
            console.log("Validation pixel:", Array.from(pixel));
            
            // Check if pixel is black (or near black)
            const isBlack = pixel[0] < 10 && pixel[1] < 10 && pixel[2] < 10;
            
            if (isBlack) {
                console.warn("Validation detected black pixels - renderer may have issues");
                
                // Apply fixes for NVIDIA GPUs
                if (isNvidiaGPU) {
                    console.log("Applying NVIDIA-specific fixes");
                    
                    // Disable problematic features and set conservative settings
                    renderer.setPixelRatio(1.0); // Use 1:1 pixel ratio
                    
                    // Reset WebGL state completely
                    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
                    gl.bindRenderbuffer(gl.RENDERBUFFER, null);
                    for (let i = 0; i < 8; i++) {
                        gl.disableVertexAttribArray(i);
                    }
                    gl.bindBuffer(gl.ARRAY_BUFFER, null);
                    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, null);
                    gl.useProgram(null);
                    
                    // Disable problematic extensions on RTX series
                    if (isRTXSeries) {
                        gl.disable(gl.DITHER);
                        renderer.shadowMap.enabled = false; // Disable shadows initially
                        
                        // Flag this renderer as requiring special handling during rendering
                        renderer.userData.requiresSpecialHandling = true;
                        renderer.userData.requiresAggressiveClearing = true;
                    }
                    
                    // Try rendering again with new settings
                    renderer.setClearColor(0x87CEEB, 1.0);
                    renderer.clear(true, true, true);
                    renderer.render(testScene, camera);
                    
                    // Check if the fix worked
                    gl.flush();
                    gl.finish();
                    gl.readPixels(
                        Math.floor(renderer.domElement.width / 2),
                        Math.floor(renderer.domElement.height / 2),
                        1, 1,
                        gl.RGBA,
                        gl.UNSIGNED_BYTE,
                        pixel
                    );
                    
                    console.log("After fixes - validation pixel:", Array.from(pixel));
                    const stillBlack = pixel[0] < 10 && pixel[1] < 10 && pixel[2] < 10;
                    
                    if (stillBlack) {
                        console.warn("Fixes did not resolve the black screen issue - will use runtime recovery");
                        renderer.userData.requiresRuntimeRecovery = true;
                    } else {
                        console.log("Fixes successfully resolved the black screen issue");
                        renderer.userData.fixesApplied = true;
                    }
                }
            } else {
                console.log("Validation successful - renderer is working properly");
                renderer.userData.validationSuccess = true;
            }
            
            // Clean up test objects
            testScene.remove(cube);
            geometry.dispose();
            material.dispose();
            
            // Mark validation as complete
            renderer.userData.frameValidationDone = true;
            return !isBlack;
            
        } catch (error) {
            console.error("Renderer validation failed:", error);
            return false;
        }
    };
    
    // Run validation in an async manner to avoid blocking the UI
    setTimeout(validateRenderer, 0);
    
    // Immediately perform a test render to detect issues early
    function validateInitialRendering() {
        try {
            // Create a simple test scene
            const testScene = new THREE.Scene();
            testScene.background = new THREE.Color(0x87CEEB); // Sky blue
            
            // Add a simple test object
            const testGeometry = new THREE.BoxGeometry(1, 1, 1);
            const testMaterial = new THREE.MeshBasicMaterial({ color: 0xff0000 });
            const testCube = new THREE.Mesh(testGeometry, testMaterial);
            testScene.add(testCube);
            
            // Create a simple camera
            const testCamera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 10);
            testCamera.position.z = 5;
            
            // Pre-render clear
            const gl = renderer.getContext();
            gl.clearColor(0.53, 0.81, 0.92, 1.0);
            gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
            
            // Perform the test render
            console.log("Performing initial test render...");
            renderer.render(testScene, testCamera);
            
            // Immediate frame validation
            const testPixel = new Uint8Array(4);
            gl.readPixels(
                Math.floor(renderer.domElement.width / 2),
                Math.floor(renderer.domElement.height / 2),
                1, 1, gl.RGBA, gl.UNSIGNED_BYTE, testPixel
            );
            
            console.log("Initial rendering test pixel value:", Array.from(testPixel));
            
            // Detect if our test render resulted in a black screen
            const isBlack = testPixel[0] < 10 && testPixel[1] < 10 && testPixel[2] < 10;
            
            if (isBlack) {
                console.warn("Initial test render resulted in black screen - applying early fixes");
                
                // Apply immediate fix
                renderer.userData.requiresAggressiveRendering = true;
                
                // Force multiple clear operations with different methods
                gl.clearColor(0.53, 0.81, 0.92, 1.0);
                gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
                
                renderer.setClearColor(0x87CEEB, 1.0);
                renderer.clear();
                
                // Try a second test render
                renderer.render(testScene, testCamera);
                
                // Check again
                gl.readPixels(
                    Math.floor(renderer.domElement.width / 2),
                    Math.floor(renderer.domElement.height / 2),
                    1, 1, gl.RGBA, gl.UNSIGNED_BYTE, testPixel
                );
                
                console.log("Second test render pixel value:", Array.from(testPixel));
                
                // If still black, we'll need more aggressive handling later
                const isStillBlack = testPixel[0] < 10 && testPixel[1] < 10 && testPixel[2] < 10;
                if (isStillBlack) {
                    console.warn("Second test render still resulted in black screen - will use aggressive runtime handling");
                    renderer.userData.requiresEarlyRecovery = true;
                } else {
                    console.log("Second test render successful - fix applied");
                }
            } else {
                console.log("Initial test render successful");
                renderer.userData.initialRenderComplete = true;
            }
            
            // Clean up test objects
            testScene.remove(testCube);
            
        } catch (error) {
            console.error("Error during initial render validation:", error);
        }
    }
    
    // Run the validation in a separate call stack to allow the DOM to update first
    setTimeout(validateInitialRendering, 0);
    
    // Function to check if rendering is actually working
    function checkRendering() {
        // Read a pixel from the center of the renderer to see if it's black
        const gl = renderer.getContext();
        const pixel = new Uint8Array(4);
        
        try {
            gl.readPixels(
                Math.floor(renderer.domElement.width / 2), 
                Math.floor(renderer.domElement.height / 2), 
                1, 1, 
                gl.RGBA, 
                gl.UNSIGNED_BYTE, 
                pixel
            );
            
            // Check if all pixels are black (or very close to black)
            const isBlack = pixel[0] < 10 && pixel[1] < 10 && pixel[2] < 10;
            
            if (isBlack && renderer.userData.renders > 5) {
                // Only consider it a black screen if we've rendered several frames
                if (!renderer.userData.blackScreenDetected) {
                    console.error("Black screen detected after multiple renders");
                    renderer.userData.blackScreenDetected = true;
                    
                    // Try to recover by recreating renderer with different settings
                    if (renderer.userData.recoveryAttempts < 3) {
                        recoverFromBlackScreen();
                    }
                }
            } else if (renderer.userData.blackScreenDetected && !isBlack) {
                // Screen is no longer black
                console.log("Screen is no longer black - rendering recovered");
                renderer.userData.blackScreenDetected = false;
            }
            
            // Log the pixel color for debugging
            if (renderer.userData.renders % 60 === 0) { // Log once per second at 60fps
                console.log("Center pixel color:", Array.from(pixel));
            }
            
        } catch (e) {
            console.warn("Error checking rendering:", e);
        }
    }
    
    // Function to try recovering from black screen
    function recoverFromBlackScreen() {
        renderer.userData.recoveryAttempts++;
        console.log(`Attempting to recover from black screen (attempt ${renderer.userData.recoveryAttempts})`);
        
        // Create a visible message
        const message = document.createElement('div');
        message.textContent = "Attempting to recover rendering...";
        message.style.position = 'absolute';
        message.style.top = '10px';
        message.style.left = '10px';
        message.style.color = 'white';
        message.style.backgroundColor = 'rgba(0,0,0,0.7)';
        message.style.padding = '10px';
        message.style.zIndex = '1000';
        document.body.appendChild(message);
        
        // Store current state
        const oldDomElement = renderer.domElement;
        const container = document.getElementById('container');
        const cameraPosition = camera.position.clone();
        const cameraRotation = camera.rotation.clone();
        const oldSize = {
            width: window.innerWidth,
            height: window.innerHeight
        };
        const oldPixelRatio = window.devicePixelRatio;
        const stats = {...renderer.userData};
        
        // Choose recovery settings based on attempt number
        let recoverySettings;
        
        switch(renderer.userData.recoveryAttempts) {
            case 1:
                // First attempt: try WebGL2 with simpler settings
                recoverySettings = {
                    alpha: false,
                    antialias: false,
                    depth: true,
                    stencil: false,
                    precision: 'mediump',
                    powerPreference: 'default',
                    failIfMajorPerformanceCaveat: false,
                    preserveDrawingBuffer: true,
                    premultipliedAlpha: false
                };
                break;
            case 2:
                // Second attempt: try WebGL1 with minimal settings
                recoverySettings = {
                    alpha: true,
                    antialias: false,
                    depth: true,
                    stencil: false,
                    precision: 'lowp',
                    preserveDrawingBuffer: true,
                    premultipliedAlpha: false
                };
                break;
            default:
                // Last attempt: absolute minimal settings
                recoverySettings = {
                    alpha: true,
                    antialias: false,
                    depth: true,
                    precision: 'lowp',
                    preserveDrawingBuffer: false
                };
        }
        
        console.log("Recovery settings:", recoverySettings);
        
        // Execute recovery in a separate call stack to allow for UI updates
        setTimeout(() => {
            try {
                // Step 1: Remove the old canvas from the DOM and dispose of the renderer
                if (container && oldDomElement.parentNode === container) {
                    container.removeChild(oldDomElement);
                }
                
                console.log("Disposed old renderer, creating new one...");
                
                // Step 2: Create a new renderer with recovery settings
                let newRenderer;
                try {
                    // Try to get WebGL2 context first if available
                    const tempCanvas = document.createElement('canvas');
                    if (tempCanvas.getContext('webgl2')) {
                        console.log("WebGL2 is available, using it for recovery");
                        // Force WebGL2 by manually creating context first
                        const canvas = document.createElement('canvas');
                        const context = canvas.getContext('webgl2', recoverySettings);
                        recoverySettings.canvas = canvas;
                        recoverySettings.context = context;
                    } else {
                        console.log("Falling back to WebGL1 for recovery");
                    }
                    
                    // Create new renderer
                    newRenderer = new THREE.WebGLRenderer(recoverySettings);
                } catch (innerError) {
                    console.error("Failed to create preferred renderer:", innerError);
                    
                    // Last resort: simplest possible renderer
                    console.log("Trying last resort renderer configuration");
                    newRenderer = new THREE.WebGLRenderer({
                        antialias: false,
                        alpha: true,
                        precision: 'lowp'
                    });
                }
                
                // Step 3: Initialize the new renderer
                newRenderer.setSize(oldSize.width, oldSize.height);
                newRenderer.setClearColor(0x87CEEB, 1); // Sky blue
                newRenderer.setPixelRatio(Math.min(oldPixelRatio, 1)); // Limit pixel ratio
                newRenderer.shadowMap.enabled = false; // Disable shadows initially
                
                // Step 4: Re-attach userData with metrics
                newRenderer.userData = stats;
                newRenderer.userData.lastRecoveryTime = Date.now();
                
                // Step 5: Add the new renderer to the DOM
                if (container) {
                    container.appendChild(newRenderer.domElement);
                } else {
                    console.error("Container not found, appending to body");
                    document.body.appendChild(newRenderer.domElement);
                }
                
                // Step 6: Update the global renderer
                renderer = newRenderer;
                
                // Step 7: Reset camera position
                camera.position.copy(cameraPosition);
                camera.rotation.copy(cameraRotation);
                
                // Step 8: Add event listeners for the new renderer
                renderer.domElement.addEventListener('webglcontextlost', function(event) {
                    event.preventDefault();
                    console.error('WebGL context lost after recovery attempt');
                    // No auto-reload after recovery to prevent infinite loops
                }, false);
                
                renderer.domElement.addEventListener('webglcontextrestored', function() {
                    console.log('WebGL context restored after recovery attempt');
                }, false);
                
                console.log("Renderer successfully recreated");
                
                // Step 9: Force a test render
                renderer.clear();
                renderer.render(scene, camera);
                
                // Test pixel color at center
                setTimeout(() => {
                    // Check if rendering is working by reading a pixel
                    try {
                        const gl = renderer.getContext();
                        const pixel = new Uint8Array(4);
                        gl.readPixels(
                            Math.floor(renderer.domElement.width / 2),
                            Math.floor(renderer.domElement.height / 2),
                            1, 1,
                            gl.RGBA,
                            gl.UNSIGNED_BYTE,
                            pixel
                        );
                        
                        console.log("After recovery - center pixel:", Array.from(pixel));
                        
                        // Update message based on pixel check
                        if (pixel[0] === 0 && pixel[1] === 0 && pixel[2] === 0) {
                            message.textContent = "Recovery incomplete - still seeing black screen. Trying a different approach...";
                            message.style.backgroundColor = "rgba(255,0,0,0.7)";
                            
                            // Try one more desperate approach: simple plane with basic material
                            if (renderer.userData.recoveryAttempts <= 3) {
                                console.log("Adding simple test geometry to scene");
                                
                                // Add a simple colored quad facing the camera
                                const basicMaterial = new THREE.MeshBasicMaterial({ 
                                    color: 0xff0000, 
                                    side: THREE.DoubleSide 
                                });
                                const testGeometry = new THREE.PlaneGeometry(5, 5);
                                const testMesh = new THREE.Mesh(testGeometry, basicMaterial);
                                testMesh.position.set(0, 0, -5);
                                testMesh.lookAt(camera.position);
                                scene.add(testMesh);
                                
                                renderer.render(scene, camera);
                            }
                        } else {
                            message.textContent = "Recovery successful!";
                            message.style.backgroundColor = "rgba(0,128,0,0.7)";
                        }
                    } catch (pixelError) {
                        console.error("Error checking pixel after recovery:", pixelError);
                    }
                    
                    // Remove the message after 5 seconds
                    setTimeout(() => {
                        if (message.parentNode) {
                            message.parentNode.removeChild(message);
                        }
                    }, 5000);
                }, 500);
                
            } catch (error) {
                console.error("Error during renderer recovery:", error);
                message.textContent = "Recovery failed. Please try reloading the page.";
                message.style.backgroundColor = "rgba(255,0,0,0.7)";
                
                // Add a reload button
                const reloadBtn = document.createElement('button');
                reloadBtn.textContent = "Reload Page";
                reloadBtn.style.marginLeft = "10px";
                reloadBtn.style.padding = "5px";
                reloadBtn.onclick = () => location.reload();
                message.appendChild(reloadBtn);
            }
        }, 0); // Execute immediately but after current call stack completes
    }
    
    // Configure the renderer with extra buffer management for problem GPUs
    renderer.setSize(window.innerWidth, window.innerHeight);
    
    // Add pre-render buffer validation for improved stability
    const gl = renderer.getContext();
    const vendorInfo = gl.getParameter(gl.VENDOR).toLowerCase();
    const isProblematicGPU = vendorInfo.includes('nvidia') || vendorInfo.includes('intel');
    
    // Start with more conservative settings and enable features after successful renders
    renderer.shadowMap.enabled = !isProblematicGPU; // Initially disable shadows on problematic GPUs
    
    // Use a safer pixel ratio to prevent resolution issues
    const safePixelRatio = Math.min(window.devicePixelRatio, 2.0);
    renderer.setPixelRatio(safePixelRatio);
    
    // Add explicit clear color with better sequencing
    renderer.setClearColor(0x87CEEB, 1.0);
    renderer.clear();
    
    // Ensure we have a fresh rendering state
    if (gl) {
        gl.disable(gl.DITHER); // Disable dithering for better performance
        gl.pixelStorei(gl.UNPACK_COLORSPACE_CONVERSION_WEBGL, gl.NONE); // Disable colorspace conversion
        
        if (isProblematicGPU) {
            // For GPUs known to have issues, disable some features temporarily
            gl.disable(gl.BLEND);
            
            // Re-enable on the next frame
            setTimeout(() => {
                try {
                    gl.enable(gl.BLEND);
                    console.log("Re-enabled blending after initialization");
                    
                    // Enable shadows after a delay if no black screens detected
                    setTimeout(() => {
                        if (!renderer.userData.blackScreenDetected) {
                            renderer.shadowMap.enabled = true;
                            console.log("Enabled shadows after successful initialization");
                        }
                    }, 2000);
                } catch (e) {
                    console.warn("Error re-enabling GPU features:", e);
                }
            }, 100);
        }
    }
    
    // Add renderer to the DOM
    const container = document.getElementById('container');
    container.appendChild(renderer.domElement);
    
    // Enable frame validation system
    const frameValidationSystem = {
        enabled: true,
        earlyFrameCount: 10, // Check frequently in the first few frames
        normalInterval: 60,  // Then check every 60 frames
        validateFrame: function(frameNum) {
            if (!this.enabled) return false;
            
            if (frameNum <= this.earlyFrameCount) {
                // Validate all early frames
                return true;
            }
            
            // After early frames, validate periodically
            return frameNum % this.normalInterval === 0;
        }
    };
    
    // Add to renderer userData
    renderer.userData.frameValidation = frameValidationSystem;
    
    // Log success
    console.log('WebGL renderer initialized successfully with enhanced buffer management');

    // Create a perspective camera
    camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.set(0, 5, 10);

// Add lights to the scene
    setupLights();
    
    // Add error handling for lost context
    renderer.domElement.addEventListener('webglcontextlost', function(event) {
        event.preventDefault();
        console.error('WebGL context lost. Please refresh the page.');
        alert('WebGL context lost. The game will attempt to reload automatically.');
        setTimeout(() => {
            location.reload();
        }, 2000);
    }, false);
    
    renderer.domElement.addEventListener('webglcontextrestored', function() {
        console.log('WebGL context restored.');
        // Re-initialize resources here if needed
    }, false);
    
    // Create the ground and grid
    createGround();
    
    // Create and add the airplane with the appropriate color
    const playerColor = isMultiplayer && playerData ? playerData.playerColor : 0x3333ff;
    airplane = createAirplane(playerColor);
    scene.add(airplane.object);
    
    // Setup keyboard event listeners
    setupControls();
    
    // Show the appropriate UI elements
    menuElements.gameInfo.style.display = 'block';
    menuElements.gameUI.style.display = 'block';
    
    if (isMultiplayer) {
        menuElements.roomInfo.style.display = 'block';
        menuElements.multiplayerStatus.textContent = `Connected as: ${playerData.playerName}`;
        
        // Start sending position updates to the server
        startPlayerUpdates();
    }
    
    // Start the animation loop
    animate();
}

// Set up lighting for the scene
function setupLights() {
    // Ambient light for general illumination
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
    scene.add(ambientLight);
    
    // Directional light for shadows and highlights
    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
    directionalLight.position.set(1, 1, 1);
    directionalLight.castShadow = true;
    directionalLight.shadow.mapSize.width = 1024;
    directionalLight.shadow.mapSize.height = 1024;
    scene.add(directionalLight);
}

// Create the ground plane and grid
function createGround() {
    // Create a green ground plane
    const groundGeometry = new THREE.PlaneGeometry(WORLD_SIZE, WORLD_SIZE);
    const groundMaterial = new THREE.MeshLambertMaterial({ 
        color: 0x71A95A, 
        side: THREE.DoubleSide 
    });
    const ground = new THREE.Mesh(groundGeometry, groundMaterial);
    ground.rotation.x = -Math.PI / 2; // Make it horizontal
    ground.position.y = -0.5;
    ground.receiveShadow = true;
    scene.add(ground);
    
    // Add grid helper for visual reference
    const gridHelper = new THREE.GridHelper(WORLD_SIZE, WORLD_SIZE);
    gridHelper.position.y = -0.49; // Just above the ground
    scene.add(gridHelper);
}

// Create a simple airplane model
function createAirplane(color = 0x3333ff) {
    // Create a group to hold all parts of the airplane
    const airplaneGroup = new THREE.Group();
    
    // Create materials for different parts
    const bodyMaterial = new THREE.MeshPhongMaterial({ color: color });
    const wingMaterial = new THREE.MeshPhongMaterial({ color: darkenColor(color, 0.8) });
    const detailMaterial = new THREE.MeshPhongMaterial({ color: 0x333333 });
    
    // Body (fuselage)
    const bodyGeometry = new THREE.BoxGeometry(0.4, 0.4, 2);
    const body = new THREE.Mesh(bodyGeometry, bodyMaterial);
    body.castShadow = true;
    airplaneGroup.add(body);
    
    // Wings
    const wingGeometry = new THREE.BoxGeometry(3, 0.1, 0.5);
    const wings = new THREE.Mesh(wingGeometry, wingMaterial);
    wings.position.set(0, 0, 0);
    wings.castShadow = true;
    airplaneGroup.add(wings);
    
    // Tail (vertical stabilizer)
    const tailGeometry = new THREE.BoxGeometry(0.1, 0.5, 0.5);
    const tail = new THREE.Mesh(tailGeometry, wingMaterial);
    tail.position.set(0, 0.25, -0.9);
    tail.castShadow = true;
    airplaneGroup.add(tail);
    
    // Horizontal stabilizer
    const hStabGeometry = new THREE.BoxGeometry(1, 0.1, 0.3);
    const hStab = new THREE.Mesh(hStabGeometry, wingMaterial);
    hStab.position.set(0, 0, -0.9);
    hStab.castShadow = true;
    airplaneGroup.add(hStab);
    
    // Propeller group
    const propellerGroup = new THREE.Group();
    propellerGroup.position.set(0, 0, 1.1);
    airplaneGroup.add(propellerGroup);
    
    // Propeller blades
    const bladeGeometry = new THREE.BoxGeometry(0.1, 0.8, 0.05);
    const blade1 = new THREE.Mesh(bladeGeometry, detailMaterial);
    const blade2 = new THREE.Mesh(bladeGeometry, detailMaterial);
    blade1.castShadow = true;
    blade2.castShadow = true;
    blade2.rotation.z = Math.PI / 2;
    propellerGroup.add(blade1);
    propellerGroup.add(blade2);
    
    // Cockpit
    const cockpitGeometry = new THREE.SphereGeometry(0.3, 8, 8, 0, Math.PI * 2, 0, Math.PI / 2);
    const cockpitMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x88ccff,
        transparent: true,
        opacity: 0.7
    });
    const cockpit = new THREE.Mesh(cockpitGeometry, cockpitMaterial);
    cockpit.position.set(0, 0.2, 0.3);
    cockpit.scale.set(0.7, 0.5, 1);
    cockpit.rotation.x = -0.2;
    airplaneGroup.add(cockpit);
    
    // Position the airplane in the scene
    airplaneGroup.position.set(0, 2, 0);
    
    // Return the airplane object with its physics properties
    return {
        object: airplaneGroup,
        propeller: propellerGroup,
        // Physics state
        velocity: 0,
        maxVelocity: 0.2,
        minVelocity: -0.05,  // Allow some backward movement
        acceleration: 0.0005,
        deceleration: 0.0003,
        rotationSpeed: 0.02,
        // Current control input states
        controls: {
            throttle: 0,
            roll: 0,
            pitch: 0,
            yaw: 0
        }
    };
}

// Set up keyboard controls
function setupControls() {
    // Track which keys are currently pressed
    const keys = {
        w: false,
        s: false,
        a: false,
        d: false,
        q: false,
        e: false,
        arrowUp: false,
        arrowDown: false
    };
    
    // Handle keydown events
    window.addEventListener('keydown', (e) => {
        const key = e.key.toLowerCase();
        if (key === 'w') keys.w = true;
        if (key === 's') keys.s = true;
        if (key === 'a') keys.a = true;
        if (key === 'd') keys.d = true;
        if (key === 'q') keys.q = true;
        if (key === 'e') keys.e = true;
        if (key === 'arrowup' || key === 'up') keys.arrowUp = true;
        if (key === 'arrowdown' || key === 'down') keys.arrowDown = true;
        
        updateControlInputs();
    });
    
    // Handle keyup events
    window.addEventListener('keyup', (e) => {
        const key = e.key.toLowerCase();
        if (key === 'w') keys.w = false;
        if (key === 's') keys.s = false;
        if (key === 'a') keys.a = false;
        if (key === 'd') keys.d = false;
        if (key === 'q') keys.q = false;
        if (key === 'e') keys.e = false;
        if (key === 'arrowup' || key === 'up') keys.arrowUp = false;
        if (key === 'arrowdown' || key === 'down') keys.arrowDown = false;
        
        updateControlInputs();
    });
    
    // Update the airplane control inputs based on keys pressed
    function updateControlInputs() {
        // Throttle (forward/backward)
        if (keys.w && !keys.s) {
            airplane.controls.throttle = 1;
        } else if (keys.s && !keys.w) {
            airplane.controls.throttle = -1;
        } else {
            airplane.controls.throttle = 0;
        }
        
        // Roll (banking left/right)
        if (keys.a && !keys.d) {
            airplane.controls.roll = 1;
        } else if (keys.d && !keys.a) {
            airplane.controls.roll = -1;
        } else {
            airplane.controls.roll = 0;
        }
        
        // Pitch (nose up/down)
        if (keys.arrowUp && !keys.arrowDown) {
            airplane.controls.pitch = 1;
        } else if (keys.arrowDown && !keys.arrowUp) {
            airplane.controls.pitch = -1;
        } else {
            airplane.controls.pitch = 0;
        }
        
        // Yaw (turn left/right)
        if (keys.q && !keys.e) {
            airplane.controls.yaw = 1;
        } else if (keys.e && !keys.q) {
            airplane.controls.yaw = -1;
        } else {
            airplane.controls.yaw = 0;
        }
    }
}

// Handle window resize
function onWindowResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
}

// Update airplane state based on controls and physics
function updateAirplane(deltaTime) {
    // Apply throttle control to change velocity
    if (airplane.controls.throttle > 0) {
        airplane.velocity = Math.min(
            airplane.velocity + airplane.acceleration * deltaTime * 60,
            airplane.maxVelocity
        );
    } else if (airplane.controls.throttle < 0) {
        airplane.velocity = Math.max(
            airplane.velocity - airplane.acceleration * deltaTime * 60,
            airplane.minVelocity
        );
    } else {
        // Natural deceleration when no throttle input
        if (airplane.velocity > 0) {
            airplane.velocity = Math.max(
                0,
                airplane.velocity - airplane.deceleration * deltaTime * 60
            );
        } else if (airplane.velocity < 0) {
            airplane.velocity = Math.min(
                0,
                airplane.velocity + airplane.deceleration * deltaTime * 60
            );
        }
    }
    
    // Apply rotation controls
    // Roll (z-axis rotation)
    if (airplane.controls.roll !== 0) {
        airplane.object.rotation.z += 
            airplane.controls.roll * airplane.rotationSpeed * deltaTime * 60;
    }
    
    // Pitch (x-axis rotation)
    if (airplane.controls.pitch !== 0) {
        airplane.object.rotation.x += 
            -airplane.controls.pitch * airplane.rotationSpeed * deltaTime * 60;
    }
    
    // Yaw (y-axis rotation)
    if (airplane.controls.yaw !== 0) {
        airplane.object.rotation.y += 
            airplane.controls.yaw * airplane.rotationSpeed * deltaTime * 60;
    }
    
    // Limit rotations to prevent flipping too much
    airplane.object.rotation.z = THREE.MathUtils.clamp(
        airplane.object.rotation.z, -Math.PI / 2, Math.PI / 2
    );
    airplane.object.rotation.x = THREE.MathUtils.clamp(
        airplane.object.rotation.x, -Math.PI / 3, Math.PI / 3
    );
    
    // Move the airplane in its current forward direction
    if (airplane.velocity !== 0) {
        // Calculate the forward direction vector (negative z-axis in local space)
        const direction = new THREE.Vector3(0, 0, -1);
        direction.applyQuaternion(airplane.object.quaternion);
        
        // Apply movement along the direction vector
        airplane.object.position.addScaledVector(
            direction, 
            airplane.velocity * deltaTime * 60
        );
        
        // Enforce world boundaries
        const halfWorld = WORLD_SIZE / 2;
        airplane.object.position.x = THREE.MathUtils.clamp(
            airplane.object.position.x, -halfWorld, halfWorld
        );
        airplane.object.position.z = THREE.MathUtils.clamp(
            airplane.object.position.z, -halfWorld, halfWorld
        );
        
        // Keep the airplane from going too high or too low
        airplane.object.position.y = THREE.MathUtils.clamp(
            airplane.object.position.y, 0.5, 10
        );
    }
    
    // Animate propeller based on velocity
    const propellerSpeed = Math.abs(airplane.velocity) * 100 + 0.1;
    airplane.propeller.rotation.z += propellerSpeed * deltaTime;
}

// Update camera position to follow the airplane
function updateCamera() {
    // Reset camera offset relative to world axes
    cameraOffset.set(0, 2, 5);
    
    // Apply the airplane's rotation to the camera offset
    cameraOffset.applyQuaternion(airplane.object.quaternion);
    
    // Position camera behind and slightly above the airplane
    camera.position.copy(airplane.object.position).add(cameraOffset);
    
    // Make camera look at the airplane
    camera.lookAt(airplane.object.position);
}

// Main animation loop
// Animation frame tracking variables
let frameCount = 0;
let lastFrameTime = 0;
let earlyFrameMonitoring = true;
let consecutiveRenderSuccesses = 0;
let firstFramesValidated = false;
let lastValidationTime = 0;

// Frame validation data
const frameValidation = {
    frameHistory: [],
    maxHistoryLength: 10,
    blackFrameCount: 0,
    validFrameThreshold: 3,
    
    // Add a frame validation result to history
    addResult: function(isValid, pixelData) {
        this.frameHistory.unshift({
            timestamp: performance.now(),
            isValid: isValid,
            pixelData: pixelData
        });
        
        // Keep history at max length
        if (this.frameHistory.length > this.maxHistoryLength) {
            this.frameHistory.pop();
        }
        
        // Update black frame count
        this.blackFrameCount = this.frameHistory.filter(f => !f.isValid).length;
        
        return this.blackFrameCount;
    },
    
    // Check if we have consecutive black frames
    hasConsecutiveBlackFrames: function(count) {
        if (this.frameHistory.length < count) return false;
        
        for (let i = 0; i < count; i++) {
            if (this.frameHistory[i].isValid) return false;
        }
        return true;
    },
    
    // Reset frame history
    reset: function() {
        this.frameHistory = [];
        this.blackFrameCount = 0;
    }
};

// Main animation loop with enhanced error handling
function animate() {
    if (currentState !== GameState.PLAYING) return;
    
    requestAnimationFrame(animate);
    
    // Increment frame counter
    frameCount++;
    
    // Track frame timing for performance monitoring
    const now = performance.now();
    const frameDelta = now - lastFrameTime;
    lastFrameTime = now;
    
    // Get the time since the last frame for smooth animation
    const deltaTime = clock.getDelta();
    
    // Update airplane physics and position
    updateAirplane(deltaTime);
    
    // Update camera to follow the airplane
    updateCamera();
    
    // Update other players in multiplayer mode
    if (isMultiplayer) {
        updateOtherPlayers(deltaTime);
        updatePlayerLabels();
    }
    
    // Pre-render validation for early frames
    // Critical for catching black screen issues immediately
    if (earlyFrameMonitoring && frameCount < 30 && (frameCount % 3 === 0)) {
        // Extra validation for the first few frames
        try {
            const gl = renderer.getContext();
            
            // Check for NVIDIA GPU to apply specific optimizations
            const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
            let isNvidiaGPU = false;
            let isRTXSeries = false;
            
            if (debugInfo) {
                const vendor = gl.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL);
                const rendererInfo = gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL);
                isNvidiaGPU = vendor.toLowerCase().includes('nvidia');
                isRTXSeries = rendererInfo.toLowerCase().includes('rtx');
                
                if (frameCount === 3) {
                    console.log(`Early frame GPU detection: NVIDIA: ${isNvidiaGPU}, RTX: ${isRTXSeries}`);
                }
            }
            
            // Add special handling for NVIDIA GPUs which are more prone to black screen issues
            if (isNvidiaGPU) {
                // Multi-step clearing process for NVIDIA GPUs
                gl.disable(gl.DITHER); // Disable dithering for better performance
                
                // For RTX series, use multiple clear methods to ensure buffer refresh
                if (isRTXSeries) {
                    // Use the scissor test to force buffer refresh in sections
                    const width = renderer.domElement.width;
                    const height = renderer.domElement.height;
                    
                    gl.enable(gl.SCISSOR_TEST);
                    
                    // Clear in 4 quadrants to ensure full buffer refresh
                    const sections = [
                        [0, 0, width/2, height/2],
                        [width/2, 0, width/2, height/2],
                        [0, height/2, width/2, height/2],
                        [width/2, height/2, width/2, height/2]
                    ];
                    
                    for (const [x, y, w, h] of sections) {
                        gl.scissor(x, y, w, h);
                        gl.clearColor(0.53, 0.81, 0.92, 1.0);
                        gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
                    }
                    
                    // Reset scissor to full viewport
                    gl.scissor(0, 0, width, height);
                    gl.disable(gl.SCISSOR_TEST);
                    
                    // Additional clear with direct WebGL commands
                    gl.clearColor(0.53, 0.81, 0.92, 1.0);
                    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
                }
                else {
                    // Standard clear for non-RTX NVIDIA GPUs
                    gl.clearColor(0.53, 0.81, 0.92, 1.0);
                    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
                }
            } 
            else {
                // Standard clear for other GPUs
                gl.clearColor(0.53, 0.81, 0.92, 1.0); // Sky blue
                gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
            }
            
            // Ensure sync before reading pixels
            gl.flush();
            
            // For early frames, check if we're rendering black pixels
            if (frameCount < 10) {
                const testPixel = new Uint8Array(4);
                
                try {
                    // Wait for rendering to complete before reading pixels
                    // This is crucial for accurate detection
                    gl.finish();
                    
                    // Read center pixel to check for black screen
                    gl.readPixels(
                        Math.floor(renderer.domElement.width / 2),
                        Math.floor(renderer.domElement.height / 2),
                        1, 1, gl.RGBA, gl.UNSIGNED_BYTE, testPixel
                    );
                    
                    // Check if we have a black pixel when we shouldn't
                    const isBlack = testPixel[0] < 10 && testPixel[1] < 10 && testPixel[2] < 10;
                    
                    if (isBlack) {
                        console.warn(`Black pixel detected in early frame ${frameCount}: [${testPixel[0]}, ${testPixel[1]}, ${testPixel[2]}, ${testPixel[3]}]`);
                        
                        // Aggressive early frame recovery for black screen
                        renderer.clear(true, true, true);
                        
                        // Create a temporary visible object to force rendering
                        if (frameCount < 5) {
                            console.log("Adding temporary object to force
    // Render the scene with comprehensive error handling and recovery
    try {
        if (renderer && scene && camera) {
            // Update renderer metadata
            if (renderer.userData) {
                const renderFrameCount = renderer.userData.renders = (renderer.userData.renders || 0) + 1;
                renderer.userData.framesSinceInit++;
                
                // Check if we need to validate this frame (early frames or periodic checks)
                const shouldValidateFrame = 
                    (earlyFrameMonitoring && renderFrameCount < 30 && renderFrameCount % 2 === 0) || // Frequent early validation
                    (renderFrameCount % 60 === 0) || // Periodic checks
                    (now - lastValidationTime > 5000); // Time-based check (at least every 5 seconds)
                
                // More aggressive early frame recovery for NVIDIA GPUs
                if (renderer.userData.requiresEarlyRecovery && renderFrameCount < 20) {
                    const gl = renderer.getContext();
                    
                    // Multi-step clearing strategy with sync points
                    console.log(`Applying enhanced frame recovery (frame ${renderFrameCount})`);
                    
                    // 1. First clear with direct WebGL commands
                    gl.clearColor(0.53, 0.81, 0.92, 1.0);
                    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT | gl.STENCIL_BUFFER_BIT);
                    gl.flush();
                    
                    // 2. Clear with THREE.js to ensure all internal state is updated
                    renderer.setClearColor(0x87CEEB, 1.0);
                    renderer.clear(true, true, true);
                    
                    // 3. Additional NVIDIA-specific clearing technique using scissor test
                    // This forces a refresh of the entire framebuffer in sections
                    const width = renderer.domElement.width;
                    const height = renderer.domElement.height;
                    
                    renderer.setScissorTest(true);
                    
                    // Clear in multiple passes to ensure the entire buffer is refreshed
                    const sections = 4;
                    const sectionHeight = height / sections;
                    
                    for (let i = 0; i < sections; i++) {
                        renderer.setScissor(0, i * sectionHeight, width, sectionHeight);
                        renderer.clear();
                    }
                    
                    // Reset scissor to full canvas
                    renderer.setScissor(0, 0, width, height);
                    renderer.setScissorTest(false);
                    
                    // Final synchronization
                    gl.flush();
                }
                
                // Pre-render validation
                if (shouldValidateFrame) {
                    lastValidationTime = now;
                    
                    try {
                        const gl = renderer.getContext();
                        const centerPixel = new Uint8Array(4);
                        
                        // Read center pixel to check if we have a black screen
                        gl.readPixels(
                            Math.floor(renderer.domElement.width / 2),
                            Math.floor(renderer.domElement.height / 2),
                            1, 1, gl.RGBA, gl.UNSIGNED_BYTE, centerPixel
                        );
                        
                        // Check if the pixel is black (or close to black)
                        const isBlack = centerPixel[0] < 10 && centerPixel[1] < 10 && centerPixel[2] < 10;
                        
                        // Add to frame validation history
                        const blackFrameCount = frameValidation.addResult(!isBlack, Array.from(centerPixel));
                        
                        // Log pixel values for debugging
                        if (renderFrameCount < 20 || renderFrameCount % 60 === 0) {
                            console.log(`Frame ${renderFrameCount} center pixel: [${centerPixel[0]}, ${centerPixel[1]}, ${centerPixel[2]}, ${centerPixel[3]}], black: ${isBlack}`);
                        }
                        
                        // Take immediate action for black frames
                        if (isBlack && renderFrameCount > 5) {
                            console.warn(`Black frame detected at frame ${renderFrameCount}`);
                            
                            // For early frames, try more aggressive recovery
                            if (renderFrameCount < 30) {
                                // Force a complete buffer refresh
                                gl.clearColor(0.53, 0.81, 0.92, 1.0);
                                gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
                                renderer.clear();
                                
                                // Immediate re-render with forced flush
                                renderer.render(scene, camera);
                                gl.flush();
                                
                                // Check again
                                gl.readPixels(
                                    Math.floor(renderer.domElement.width / 2),
                                    Math.floor(renderer.domElement.height / 2),
                                    1, 1, gl.RGBA, gl.UNSIGNED_BYTE, centerPixel
                                );
                                
                                const stillBlack = centerPixel[0] < 10 && centerPixel[1] < 10 && centerPixel[2] < 10;
                                console.log(`Recovery result: ${stillBlack ? 'still black' : 'fixed'}, pixel: [${centerPixel[0]}, ${centerPixel[1]}, ${centerPixel[2]}, ${centerPixel[3]}]`);
                            }
                            
                            // Check for persistent black screen issue
                            if (frameValidation.hasConsecutiveBlackFrames(3)) {
                                console.error("Persistent black screen detected - triggering full recovery");
                                
                                // Create visible indicator of recovery
                                const recoveryMessage = document.createElement('div');
                                recoveryMessage.textContent = "Recovering from black screen...";
                                recoveryMessage.style.position = 'absolute';
                                recoveryMessage.style.top = '50%';
                                recoveryMessage.style.left = '50%';
                                recoveryMessage.style.transform = 'translate(-50%, -50%)';
                                recoveryMessage.style.backgroundColor = 'rgba(255, 0, 0, 0.7)';
                                recoveryMessage.style.color = 'white';
                                recoveryMessage.style.padding = '10px';
                                recoveryMessage.style.borderRadius = '5px';
                                recoveryMessage.style.zIndex = '1000';
                                document.body.appendChild(recoveryMessage);
                                
                                // Execute full recovery
                                try {
                                    // 1. Force complete buffer reset
                                    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT | gl.STENCIL_BUFFER_BIT);
                                    gl.flush();
                                    gl.finish();
                                    
                                    // 2. Reset renderer state
                                    renderer.clear(true, true, true);
                                    
                                    // 3. Try to recreate problematic textures or materials
                                    scene.background = new THREE.Color(0x87CEEB);
                                    
                                    // 4. Force a re-render
                                    renderer.render(scene, camera);
                                    gl.flush();
                                    
                                    // 5. If the problem persists, trigger a more complete recovery
                                    setTimeout(() => {
                                        // Check if we're still black
                                        const checkPixel = new Uint8Array(4);
                                        gl.readPixels(
                                            Math.floor(renderer.domElement.width / 2),
                                            Math.floor(renderer.domElement.height / 2),
                                            1, 1, gl.RGBA, gl.UNSIGNED_BYTE, checkPixel
                                        );
                                        
                                        if (checkPixel[0] < 10 && checkPixel[1] < 10 && checkPixel[2] < 10) {
                                            console.error("Recovery failed - trying renderer recreation");
                                            // Use the existing recovery function
                                            recoverFromBlackScreen();
                                        } else {
                                            console.log("Recovery successful!");
                                            frameValidation.reset();
                                        }
                                        
                                        // Remove recovery message
                                        if (recoveryMessage.parentNode) {
                                            recoveryMessage.parentNode.removeChild(recoveryMessage);
                                        }
                                    }, 500);
                                } catch (err) {
                                    console.error("Error during black screen recovery:", err);
                                    // Fallback to full renderer recreation
                                    recoverFromBlackScreen();
                                    
                                    // Remove recovery message after a delay
                                    setTimeout(() => {
                                        if (recoveryMessage.parentNode) {
                                            recoveryMessage.parentNode.removeChild(recoveryMessage);
                                        }
                                    }, 5000);
                                }
                            }
                        }
                    } catch (e) {
                        console.error("Frame validation error:", e);
                    }
                }
            }
            
                // Render the scene after all validation
                try {
                    // Special handling for NVIDIA GPUs that require aggressive clearing
                    if (renderer.userData.requiresAggressiveClearing && frameCount < 20) {
                        const gl = renderer.getContext();
                        
                        // Perform multi-pass clearing for problematic early frames on NVIDIA GPUs
                        gl.clearColor(0.53, 0.81, 0.92, 1.0);
                        gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
                        gl.flush();
                        
                        if (frameCount < 5) {
                            console.log(`Frame ${frameCount}: Applying aggressive clearing for NVIDIA GPU`);
                        }
                    }
                    
                    // Set clear color directly before rendering
                    renderer.setClearColor(0x87CEEB, 1.0);
                    
                    // Special handling for problematic renderers that require additional processing
                    if (renderer.userData.requiresSpecialHandling && frameCount < 10) {
                        // Clear with higher priority
                        renderer.clear(true, true, true);
                        
                        // For very early frames on problematic GPUs, render a simple scene first
                        if (frameCount < 3) {
                            // Create a simple scene with just the sky
                            const simpleScene = new THREE.Scene();
                            simpleScene.background = new THREE.Color(0x87CEEB);
                            
                            // Simple box to force proper rendering pipeline
                            const tempGeometry = new THREE.BoxGeometry(1, 1, 1);
                            const tempMaterial = new THREE.MeshBasicMaterial({ color: 0xff0000 });
                            const tempMesh = new THREE.Mesh(tempGeometry, tempMaterial);
                            tempMesh.position.set(0, 0, -5);
                            simpleScene.add(tempMesh);
                            
                            // Render the simple scene first
                            renderer.render(simpleScene, camera);
            } catch (renderError) {
                console.error("Error rendering frame:", renderError);
                
                // If we're still in early frames, try more aggressive recovery
                if (frameCount < 30) {
                    const gl = renderer.getContext();
                    if (gl) {
                        try {
                            // Emergency clear and flush
                            gl.clearColor(0.53, 0.81, 0.92, 1.0);
                            gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
                            gl.flush();
                        } catch (e) {
                            console.error("Failed emergency clear:", e);
                        }
                    }
                }
            }
        }
    } catch (outerError) {
        console.error("Critical rendering error:", outerError);
    }
    
    // Add specific NVIDIA driver bug workaround
            // Some NVIDIA drivers have issues with preserveDrawingBuffer: false
            if (renderer.userData && renderer.userData.renders === 5) {
                const gl = renderer.getContext();
                const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
                
                if (debugInfo) {
                    const vendor = gl.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL);
                    const rendererInfo = gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL);
                    
                    if (vendor.includes('NVIDIA')) {
                        console.log("Applying NVIDIA-specific rendering fixes...");
                        const isRTX = rendererInfo.includes('RTX');
                        const isNVIDIAAngle = rendererInfo.includes('ANGLE');
                        const isRTX30Series = rendererInfo.includes('RTX 30');
                        const isRTX40Series = rendererInfo.includes('RTX 40');
                        
                        console.log(`NVIDIA GPU details: RTX: ${isRTX}, ANGLE: ${isNVIDIAAngle}, 30 Series: ${isRTX30Series}, 40 Series: ${isRTX40Series}`);
                        
                        // Store the original clear color
                        const originalClearColor = new THREE.Color();
                        renderer.getClearColor(originalClearColor);
                        const originalClearAlpha = renderer.getClearAlpha();
                        
                        // Perform immediate rendering validation to detect issues early
                        try {
                            // Force a synchronous clear and render to validate context
                            const gl = renderer.getContext();
                            
                            // Clear with explicit WebGL commands first
                            gl.clearColor(0.53, 0.81, 0.92, 1.0);
                            gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
                            
                            // Make sure it completes
                            gl.flush();
                            
                            // Read a pixel to verify rendering is working
                            const testPixel = new Uint8Array(4);
                            gl.readPixels(
                                Math.floor(renderer.domElement.width / 2),
                                Math.floor(renderer.domElement.height / 2),
                                1, 1, gl.RGBA, gl.UNSIGNED_BYTE, testPixel
                            );
                            
                            console.log("Initial rendering test pixel value:", Array.from(testPixel));
                            
                            // Check if we're getting a black pixel when we shouldn't be
                            if (testPixel[0] < 10 && testPixel[1] < 10 && testPixel[2] < 10) {
                                console.warn("Initial render test shows black pixels - activating aggressive mode");
                                // Set a flag for more aggressive rendering approach
                                renderer.userData.requiresAggressiveRendering = true;
                            }
                        } catch (e) {
                            console.warn("Initial rendering validation failed:", e);
                        }
                        
                        // Enhanced clearing strategy for NVIDIA GPUs
                        renderer.autoClear = true;
                        renderer.autoClearColor = true;
                        renderer.autoClearDepth = true;
                        renderer.autoClearStencil = false; // Save some performance
                        
                        // For RTX cards, use more aggressive settings
                        if (isRTX) {
                            // Force high precision depth buffer
                            const gl = renderer.getContext();
                            
                            // Try to enable more stable rendering extensions if available
                            const depthTexture = gl.getExtension('WEBGL_depth_texture');
                            const drawBuffers = gl.getExtension('WEBGL_draw_buffers');
                            const vertexArrayObject = gl.getExtension('OES_vertex_array_object');
                            
                            if (depthTexture) {
                                console.log("WEBGL_depth_texture extension enabled");
                            }
                            
                            // Set more conservative WebGL state
                            gl.disable(gl.DITHER); // Disable dithering for better performance
                            if (renderer.userData.requiresAggressiveRendering) {
                                console.log("Using aggressive buffer management for RTX GPU");
                                // For problematic RTX cards, disable depth test temporarily
                                // and re-enable during normal rendering
                                gl.disable(gl.DEPTH_TEST);
                                setTimeout(() => {
                                    gl.enable(gl.DEPTH_TEST);
                                }, 1000);
                            }
                        }
                        
                        // Use scissor test to ensure proper buffer refresh
                        // This forces the entire viewport to refresh properly
                        renderer.setScissorTest(true);
                        renderer.setScissor(0, 0, renderer.domElement.width, renderer.domElement.height);
                        
                        // Add frame counter for validation
                        renderer.userData.frameCounter = 0;
                        renderer.userData.lastValidationTime = 0;
                        
                        // Create a more robust rendering wrapper with improved error handling
                        const originalRender = renderer.render;
                        let renderErrorCount = 0;
                        
                        renderer.render = function(scene, camera) {
                            try {
                                // Increment frame counter for validation
                                renderer.userData.frameCounter = (renderer.userData.frameCounter || 0) + 1;
                                
                                // Check if context is still valid
                                if (gl.isContextLost()) {
                                    console.warn("Context lost before render, attempting to recover...");
                                    return; // Skip rendering this frame
                                }
                                
                                // Check if we need early validation (every 30 frames)
                                const now = performance.now();
                                const needsValidation = now - (renderer.userData.lastValidationTime || 0) > 2000;
                                
                                if (isRTX && needsValidation) {
                                    renderer.userData.lastValidationTime = now;
                                    
                                    // Pre-render validation for problematic frames
                                    const testPixel = new Uint8Array(4);
                                    
                                    try {
                                        gl.readPixels(
                                            Math.floor(renderer.domElement.width / 2),
                                            Math.floor(renderer.domElement.height / 2),
                                            1, 1, gl.RGBA, gl.UNSIGNED_BYTE, testPixel
                                        );
                                        
                                        const isBlack = testPixel[0] < 10 && testPixel[1] < 10 && testPixel[2] < 10;
                                        
                                        if (isBlack && renderer.userData.frameCounter > 10) {
                                            console.warn(`Detected potential black frame at frame ${renderer.userData.frameCounter}`);
                                            // Force more aggressive clearing
                                            gl.clearColor(0.53, 0.81, 0.92, 1.0);
                                            gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT | gl.STENCIL_BUFFER_BIT);
                                            
                                            // Try a different clear approach
                                            this.setClearColor(0x87CEEB, 1.0);
                                            this.clear(true, true, true);
                                        }
                                    } catch (e) {
                                        // Ignore validation errors
                                    }
                                }
                                
                                // Multi-step synchronized clear process for RTX cards
                                if (isRTX) {
                                    // 1. First clear with direct WebGL commands
                                    gl.clearColor(0.53, 0.81, 0.92, 1.0); // Sky blue
                                    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
                                    
                                    // Synchronization point
                                    gl.flush();
                                    
                                    // 2. Then use Three.js clear
                                    this.setClearColor(0x87CEEB, 1.0);
                                    this.clear();
                                    
                                    // 3. For RTX 30/40 series, add extra buffer swap
                                    if (isRTX30Series || isRTX40Series) {
                                        // Use an additional scissor clear to force buffer update
                                        const width = this.domElement.width;
                                        const height = this.domElement.height;
                                        
                                        // Clear in 4 quadrants to ensure full buffer refresh
                                        const quadrants = [
                                            [0, 0, width/2, height/2],
                                            [width/2, 0, width/2, height/2],
                                            [0, height/2, width/2, height/2],
                                            [width/2, height/2, width/2, height/2]
                                        ];
                                        
                                        for (const [x, y, w, h] of quadrants) {
                                            this.setScissor(x, y, w, h);
                                            this.clear();
                                        }
                                        
                                        // Reset scissor to full screen
                                        this.setScissor(0, 0, width, height);
                                    }
                                    
                                    // 4. Reset to original clear color (if different)
                                    if (originalClearColor.getHex() !== 0x87CEEB || originalClearAlpha !== 1.0) {
                                        this.setClearColor(originalClearColor, originalClearAlpha);
                                    }
                                } else {
                                    // Standard clear for non-RTX NVIDIA GPUs
                                    this.clear();
                                }
                                
                                // Call the original render function with error boundary
                                const renderStartTime = performance.now();
                                originalRender.call(this, scene, camera);
                                const renderTime = performance.now() - renderStartTime;
                                
                                // Log slow frames for debugging
                                if (renderTime > 50) {
                                    console.warn(`Slow frame detected: ${renderTime.toFixed(2)}ms`);
                                    
                                    // Capture information about slow frames for debugging
                                    if (isRTX) {
                                        // RTX-specific frame monitoring
                                        renderer.userData.slowFrames = (renderer.userData.slowFrames || 0) + 1;
                                        
                                        // If we're getting too many slow frames, try to optimize
                                        if (renderer.userData.slowFrames > 10) {
                                            console.log("Too many slow frames - optimizing RTX rendering");
                                            
                                            // Reset slow frame counter
                                            renderer.userData.slowFrames = 0;
                                            
                                            // Aggressively manage buffers for RTX cards
                                            gl.finish(); // Force command buffer completion
                                            
                                            // Reduce shader complexity if possible
                                            if (renderer.shadowMap.enabled) {
                                                console.log("Temporarily disabling shadow maps");
                                                renderer.shadowMap.enabled = false;
                                                
                                                // Re-enable shadows after a few seconds
                                                setTimeout(() => {
                                                    renderer.shadowMap.enabled = true;
                                                }, 5000);
                                            }
                                        }
                                    }
                                }
                                
                                // Perform frame validation for RTX cards
                                if (isRTX && renderer.userData.frameCounter % 120 === 0) {
                                    // Periodically check for black screen issues with deferred execution
                                    setTimeout(() => {
                                        try {
                                            const validationPixel = new Uint8Array(4);
                                            gl.readPixels(
                                                Math.floor(renderer.domElement.width / 2),
                                                Math.floor(renderer.domElement.height / 2),
                                                1, 1, gl.RGBA, gl.UNSIGNED_BYTE, validationPixel
                                            );
                                            
                                            // Log pixel values for debugging
                                            console.log(`RTX frame validation: [${validationPixel[0]}, ${validationPixel[1]}, ${validationPixel[2]}, ${validationPixel[3]}]`);
                                            
                                            // Check for completely black or invalid pixels
                                            if (validationPixel[0] === 0 && validationPixel[1] === 0 && validationPixel[2] === 0) {
                                                console.warn("Black frame detected in validation - triggering refresh");
                                                
                                                // Force a complete buffer refresh
                                                gl.clearColor(0.53, 0.81, 0.92, 1.0);
                                                gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
                                                renderer.clear();
                                                renderer.render(scene, camera);
                                            }
                                        } catch (e) {
                                            console.error("Frame validation error:", e);
                                        }
                                    }, 0);
                                }
                                
                                // Additional buffer management for RTX series cards
                                if (isRTX && (isRTX30Series || isRTX40Series)) {
                                    // For newer RTX cards, implement double-buffer rendering strategy
                                    // This helps prevent the black screen issue on some drivers
                                    gl.flush();
                                    
                                    // For RTX 30/40 series, periodically force a complete pipeline flush
                                    if (renderer.userData.frameCounter % 300 === 0) {
                                        // Force completion of all GPU commands in the queue
                                        gl.finish();
                                        
                                        // Log memory information if available
                                        const debugExt = gl.getExtension('WEBGL_debug_renderer_info');
                                        if (debugExt) {
                                            console.log("GPU: " + gl.getParameter(debugExt.UNMASKED_RENDERER_WEBGL));
                                        }
                                    }
                                }
                            } catch (error) {
                                renderErrorCount++;
                                console.error(`Render error (${renderErrorCount}):`, error);
                                
                                // If we have persistent errors, try recovery
                                if (renderErrorCount > 5) {
                                    console.warn("Multiple render errors, attempting more aggressive recovery");
                                    
                                    // Reset WebGL state
                                    try {
                                        gl.flush();
                                        gl.finish();
                                        
                                        // Force a complete clear
                                        gl.clearColor(0, 0, 0, 1);
                                        gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT | gl.STENCIL_BUFFER_BIT);
                                        
                                        // Reset Three.js state
                                        this.clear();
                                        renderErrorCount = 0;
                                    } catch (e) {
                                        console.error("Recovery attempt failed:", e);
                                    }
                                }
                            }
                        };
                        
                        // Enhanced error handling for context loss
                        renderer.domElement.addEventListener('webglcontextlost', function(event) {
                            event.preventDefault();
                            console.error('NVIDIA GPU context lost - attempting to restore');
                            
                            // Log detailed information for debugging
                            console.log('Context loss details:', {
                                timestamp: new Date().toISOString(),
                                gpuVendor: vendor,
                                gpuRenderer: rendererInfo,
                                isRTX: isRTX,
                                isAngle: isNVIDIAAngle
                            });
                        }, false);
                        
                        // Create a more efficient memory management system
                        // NVIDIA GPUs benefit from explicit resource management
                        const memoryManager = {
                            cleanup: function() {
                                if (!renderer || !renderer.getContext) return;
                                try {
                                    // Ensure all commands complete
                                    gl.finish();
                                    
                                    // Force garbage collection hint (not guaranteed but helpful)
                                    if (window.gc) window.gc();
                                    
                                    if (isRTX) {
                                        // Additional cleanup for RTX GPUs
                                        // This helps prevent VRAM leaks
                                        const ext = gl.getExtension('WEBGL_lose_context');
                                        if (ext && Math.random() < 0.01) { // 1% chance to do a full reset
                                            console.log("Performing periodic context refresh");
                                            
                                            // Store the current position of airplane
                                            const currentPos = airplane ? airplane.object.position.clone() : null;
                                            const currentRot = airplane ? airplane.object.rotation.clone() : null;
                                            
                                            // Schedule a context refresh
                                            setTimeout(() => {
                                                try {
                                                    // Force context to be lost and restored
                                                    ext.loseContext();
                                                    
                                                    // Schedule context restoration
                                                    setTimeout(() => {
                                                        try {
                                                            ext.restoreContext();
                                                            console.log("Context manually restored");
                                                            
                                                            // Restore airplane position if needed
                                                            if (airplane && currentPos && currentRot) {
                                                                airplane.object.position.copy(currentPos);
                                                                airplane.object.rotation.copy(currentRot);
                                                            }
                                                        } catch (e) {
                                                            console.error("Error restoring context:", e);
                                                        }
                                                    }, 500);
                                                } catch (e) {
                                                    console.error("Error during context refresh:", e);
                                                }
                                            }, 100);
                                        }
                    }
                }
            }
        }
    } catch (error) {
        console.error("Render error:", error);
    }
}

// Setup menu button listeners
function setupMenuListeners() {
    // Single player button
    document.getElementById('single-player-btn').addEventListener('click', () => {
        hideAllMenus();
        initGame(false);
    });
    
    // Multiplayer button
    document.getElementById('multiplayer-btn').addEventListener('click', () => {
        hideAllMenus();
        menuElements.multiplayerMenu.style.display = 'flex';
        setTimeout(() => menuElements.multiplayerMenu.classList.add('active'), 10);
    });
    
    // Back to main menu button
    document.getElementById('back-to-main-btn').addEventListener('click', () => {
        hideAllMenus();
        menuElements.mainMenu.style.display = 'flex';
        setTimeout(() => menuElements.mainMenu.classList.add('active'), 10);
    });
    
    // Join room button
    document.getElementById('join-room-btn').addEventListener('click', () => {
        const roomNumber = menuElements.roomNumberInput.value.trim();
        const playerName = menuElements.playerNameInput.value.trim() || `Player_${Math.floor(Math.random() * 10000)}`;
        
        if (roomNumber && roomNumber.length === 6) {
            connectToServer();
            joinRoom(roomNumber, playerName);
        } else {
            showError('Please enter a valid 6-digit room number');
        }
    });
    
    // Create room button
    document.getElementById('create-room-btn').addEventListener('click', () => {
        const playerName = menuElements.playerNameInput.value.trim() || `Player_${Math.floor(Math.random() * 10000)}`;
        connectToServer();
        createRoom(playerName);
    });
    
    // Exit game button
    document.getElementById('exit-game-btn').addEventListener('click', () => {
        exitGame();
    });
}

// Connect to the WebSocket server
function connectToServer() {
    if (socket && socket.connected) return; // Already connected
    
    multiplayerState = MultiplayerState.CONNECTING;
    
    // Use socket from window object, which is configured in index.html
    socket = window.gameSocket || null;
    
    // If socket isn't available, create it (fallback)
    if (!socket) {
        console.warn("Socket not found from window object, creating new socket");
        // Connect to server using same logic as index.html
        const serverUrl = getServerUrl();
        socket = io(serverUrl, {
            reconnection: true,
            reconnectionAttempts: 5,
            reconnectionDelay: 1000
        });
    }
    
    // Function to get server URL (duplicate of the one in index.html for fallback)
    function getServerUrl() {
        // Check for query parameter (useful for testing)
        const urlParams = new URLSearchParams(window.location.search);
        const serverParam = urlParams.get('server');
        if (serverParam) {
            return serverParam;
        }
        
        // Check for production domain
        if (window.location.hostname !== 'localhost' && window.location.hostname !== '127.0.0.1') {
            return 'https://flight-sim-server.herokuapp.com';
        }
        
        // Fallback to localhost for development
        return 'http://localhost:3000';
    }
    
    // Set up socket event handlers
    setupSocketHandlers();
}

// Set up WebSocket event handlers
function setupSocketHandlers() {
    // Connection events
    socket.on('connect', () => {
        console.log('Connected to server');
        multiplayerState = MultiplayerState.CONNECTED;
    });
    
    socket.on('disconnect', () => {
        console.log('Disconnected from server');
        multiplayerState = MultiplayerState.DISCONNECTED;
        if (currentState === GameState.PLAYING && isMultiplayer) {
            showError('Disconnected from server. Returning to menu...');
            setTimeout(exitGame, 2000);
        }
    });
    
    socket.on('connect_error', (error) => {
        console.error('Connection error:', error);
        multiplayerState = MultiplayerState.ERROR;
        showError('Failed to connect to server. Please try again.');
    });
    
    // Game events
    socket.on('roomCreated', (data) => {
        console.log('Room created:', data);
        playerData = data;
        currentRoom = data.roomCode;
        
        // Update the UI
        menuElements.currentRoomDisplay.textContent = currentRoom;
        
        // Start the game
        hideAllMenus();
        initGame(true);
    });
    
    socket.on('roomJoined', (data) => {
        console.log('Room joined:', data);
        playerData = {
            playerId: data.playerId,
            playerName: data.playerName,
            playerColor: data.playerColor,
            roomCode: data.roomCode
        };
        currentRoom = data.roomCode;
        
        // Add other players to the scene
        data.players.forEach(player => {
            if (player.id !== playerData.playerId) {
                addOtherPlayer(player);
            }
        });
        
        // Update the UI
        menuElements.currentRoomDisplay.textContent = currentRoom;
        
        // Start the game
        hideAllMenus();
        initGame(true);
    });
    
    socket.on('playerJoined', (data) => {
        console.log('Player joined:', data);
        addOtherPlayer(data);
    });
    
    socket.on('playerLeft', (data) => {
        console.log('Player left:', data.id);
        removeOtherPlayer(data.id);
    });
    
    socket.on('playerUpdated', (data) => {
        updateOtherPlayerData(data);
    });
    
    socket.on('playerCount', (data) => {
        menuElements.playerCountDisplay.textContent = `${data.count}/${data.maxPlayers}`;
    });
    
    socket.on('error', (data) => {
        console.error('Server error:', data);
        showError(data.message);
    });
}

// Join an existing room
function joinRoom(roomCode, playerName) {
    if (multiplayerState !== MultiplayerState.CONNECTED) {
        socket.once('connect', () => {
            socket.emit('joinRoom', { roomCode, name: playerName });
        });
    } else {
        socket.emit('joinRoom', { roomCode, name: playerName });
    }
}

// Create a new room
function createRoom(playerName) {
    if (multiplayerState !== MultiplayerState.CONNECTED) {
        socket.once('connect', () => {
            socket.emit('createRoom', playerName);
        });
    } else {
        socket.emit('createRoom', playerName);
    }
}

// Start sending player updates to the server
function startPlayerUpdates() {
    if (!isMultiplayer || !socket) return;
    
    // Clear any existing interval
    if (playerUpdateInterval) clearInterval(playerUpdateInterval);
    
    // Set up a new interval to send player position/rotation updates
    playerUpdateInterval = setInterval(() => {
        if (socket && socket.connected && airplane) {
            const playerPosition = airplane.object.position;
            const playerRotation = airplane.object.rotation;
            
            socket.emit('updatePlayer', {
                position: {
                    x: playerPosition.x,
                    y: playerPosition.y,
                    z: playerPosition.z
                },
                rotation: {
                    x: playerRotation.x,
                    y: playerRotation.y,
                    z: playerRotation.z
                },
                velocity: airplane.velocity
            });
        }
    }, updateRate);
}

// Add another player to the scene
function addOtherPlayer(playerInfo) {
    if (otherPlayers.has(playerInfo.id)) return; // Player already exists
    
    const otherAirplane = createAirplane(playerInfo.color);
    
    // Position the airplane
    if (playerInfo.position) {
        otherAirplane.object.position.set(
            playerInfo.position.x,
            playerInfo.position.y,
            playerInfo.position.z
        );
    }
    
    // Set rotation
    if (playerInfo.rotation) {
        otherAirplane.object.rotation.set(
            playerInfo.rotation.x,
            playerInfo.rotation.y,
            playerInfo.rotation.z
        );
    }
    
    // Add to scene
    scene.add(otherAirplane.object);
    
    // Store the player
    otherPlayers.set(playerInfo.id, {
        object: otherAirplane.object,
        propeller: otherAirplane.propeller,
        data: playerInfo,
        targetPosition: new THREE.Vector3(
            playerInfo.position?.x || 0,
            playerInfo.position?.y || 2,
            playerInfo.position?.z || 0
        ),
        targetRotation: new THREE.Euler(
            playerInfo.rotation?.x || 0,
            playerInfo.rotation?.y || 0,
            playerInfo.rotation?.z || 0
        ),
        velocity: playerInfo.velocity || 0
    });
    
    // Create player name label
    createPlayerLabel(playerInfo.id, playerInfo.name);
    
    console.log(`Added player: ${playerInfo.name} (${playerInfo.id})`);
}

// Create a floating name label for a player
function createPlayerLabel(playerId, playerName) {
    // Create a div element for the name tag
    const nameLabel = document.createElement('div');
    nameLabel.className = 'player-tag';
    nameLabel.textContent = playerName;
    nameLabel.style.position = 'absolute';
    nameLabel.style.pointerEvents = 'none';
    nameLabel.style.display = 'none'; // Will be shown when positioned
    document.body.appendChild(nameLabel);
    
    // Store the label element
    playerNameLabels.set(playerId, nameLabel);
}

// Remove a player from the scene
function removeOtherPlayer(playerId) {
    if (!otherPlayers.has(playerId)) return;
    
    const player = otherPlayers.get(playerId);
    
    // Remove from scene
    scene.remove(player.object);
    
    // Remove name label
    if (playerNameLabels.has(playerId)) {
        const nameLabel = playerNameLabels.get(playerId);
        if (nameLabel && nameLabel.parentNode) {
            nameLabel.parentNode.removeChild(nameLabel);
        }
        playerNameLabels.delete(playerId);
    }
    
    // Remove from map
    otherPlayers.delete(playerId);
}

// Update other player's data when receiving updates
function updateOtherPlayerData(data) {
    if (!data.id || !otherPlayers.has(data.id)) return;
    
    const player = otherPlayers.get(data.id);
    
    // Update target position for smooth interpolation
    if (data.position) {
        player.targetPosition.set(
            data.position.x,
            data.position.y,
            data.position.z
        );
    }
    
    // Update target rotation for smooth interpolation
    if (data.rotation) {
        player.targetRotation.set(
            data.rotation.x,
            data.rotation.y,
            data.rotation.z
        );
    }
    
    // Update velocity
    if (data.velocity !== undefined) {
        player.velocity = data.velocity;
    }
}

// Update all other players' positions/rotations with interpolation
function updateOtherPlayers(deltaTime) {
    otherPlayers.forEach((player, id) => {
        // Smoothly interpolate position
        player.object.position.lerp(player.targetPosition, smoothingFactor);
        
        // Smoothly interpolate rotation
        const currentRotation = player.object.rotation;
        currentRotation.x = lerpAngle(currentRotation.x, player.targetRotation.x, smoothingFactor);
        currentRotation.y = lerpAngle(currentRotation.y, player.targetRotation.y, smoothingFactor);
        currentRotation.z = lerpAngle(currentRotation.z, player.targetRotation.z, smoothingFactor);
        
        // Animate propeller
        const propellerSpeed = Math.abs(player.velocity) * 100 + 0.1;
        player.propeller.rotation.z += propellerSpeed * deltaTime;
    });
}

// Update player name labels to follow their airplanes
function updatePlayerLabels() {
    otherPlayers.forEach((player, id) => {
        const label = playerNameLabels.get(id);
        if (!label) return;
        
        // Get the position of the player in screen space
        const position = player.object.position.clone();
        position.y += 0.8; // Position above the airplane
        
        // Convert 3D position to screen position
        const screenPosition = position.project(camera);
        
        // Convert to CSS coordinates
        const x = (screenPosition.x * 0.5 + 0.5) * window.innerWidth;
        const y = (-screenPosition.y * 0.5 + 0.5) * window.innerHeight;
        
        // Check if the player is in front of the camera (not behind)
        if (screenPosition.z < 1) {
            label.style.display = 'block';
            label.style.transform = `translate(-50%, -50%) translate(${x}px, ${y}px)`;
        } else {
            label.style.display = 'none'; // Hide if behind camera
        }
    });
}

// Hide all menu screens
function hideAllMenus() {
    menuElements.mainMenu.classList.remove('active');
    menuElements.multiplayerMenu.classList.remove('active');
    
    setTimeout(() => {
        menuElements.mainMenu.style.display = 'none';
        menuElements.multiplayerMenu.style.display = 'none';
    }, 400); // Wait for fade-out animation
}

// Show error message
function showError(message) {
    // Create an error element
    const errorContainer = document.createElement('div');
    errorContainer.className = 'error fade-in';
    errorContainer.textContent = message;
    
    // Add to body
    document.body.appendChild(errorContainer);
    
    // Remove after a few seconds
    setTimeout(() => {
        if (errorContainer.parentNode) {
            errorContainer.classList.remove('fade-in');
            setTimeout(() => {
                if (errorContainer.parentNode) {
                    errorContainer.parentNode.removeChild(errorContainer);
                }
            }, 500);
        }
    }, 5000);
    
    console.error(message);
}

// Exit the game and return to menu
function exitGame() {
    // Stop animation loop
    currentState = GameState.MENU;
    
    // Clean up multiplayer resources
    if (isMultiplayer && socket) {
        // Stop sending updates
        if (playerUpdateInterval) {
            clearInterval(playerUpdateInterval);
            playerUpdateInterval = null;
        }
        
        // Leave the room
        socket.emit('leaveRoom');
        
        // Remove all other players
        otherPlayers.forEach((player, id) => {
            removeOtherPlayer(id);
        });
        
        // Clear player data
        otherPlayers.clear();
        playerNameLabels.clear();
        currentRoom = null;
        playerData = null;
    }
    
    // Clean up THREE.js resources
    if (renderer) {
        const container = document.getElementById('container');
        if (container && container.contains(renderer.domElement)) {
            container.removeChild(renderer.domElement);
        }
        renderer.dispose();
    }
    
    // Reset scene
    scene = null;
    camera = null;
    renderer = null;
    airplane = null;
    
    // Hide game UI
    menuElements.gameInfo.style.display = 'none';
    menuElements.roomInfo.style.display = 'none';
    menuElements.gameUI.style.display = 'none';
    
    // Show main menu
    menuElements.mainMenu.style.display = 'flex';
    setTimeout(() => menuElements.mainMenu.classList.add('active'), 10);
}

// Utility function to darken a color
function darkenColor(color, factor = 0.7) {
    const hex = color.toString(16).padStart(6, '0');
    let r = parseInt(hex.substr(0, 2), 16);
    let g = parseInt(hex.substr(2, 2), 16);
    let b = parseInt(hex.substr(4, 2), 16);
    
    r = Math.floor(r * factor);
    g = Math.floor(g * factor);
    b = Math.floor(b * factor);
    
    return (r << 16) + (g << 8) + b;
}

// Utility function for smooth angle interpolation
function lerpAngle(start, end, t) {
    // Ensure angles are in the range (-PI, PI)
    const startNormalized = normalizeAngle(start);
    const endNormalized = normalizeAngle(end);
    
    // Find the shortest path
    let delta = endNormalized - startNormalized;
    if (delta > Math.PI) delta -= 2 * Math.PI;
    if (delta < -Math.PI) delta += 2 * Math.PI;
    
    // Interpolate
    return start + delta * t;
}

// Normalize angle to (-PI, PI)
function normalizeAngle(angle) {
    return ((angle + Math.PI) % (2 * Math.PI)) - Math.PI;
}

// Clean up resources when page is unloaded
window.addEventListener('beforeunload', () => {
    if (socket) {
        socket.disconnect();
    }
    
    if (playerUpdateInterval) {
        clearInterval(playerUpdateInterval);
    }
});

// Start the application
init();

