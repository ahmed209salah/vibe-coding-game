import { create } from "zustand";
import { subscribeWithSelector } from "zustand/middleware";
import * as THREE from "three";

export type GamePhase = "loading" | "menu" | "create" | "join" | "playing" | "paused";
export type ConnectionStatus = "disconnected" | "connecting" | "connected";

// Player interface for multiplayer
export interface Player {
  id: string;
  name: string;
  position: THREE.Vector3;
  rotation: THREE.Euler;
  color: number;
  velocity: number;
}

interface FlightSimulatorState {
  // Game state
  phase: GamePhase;
  singlePlayer: boolean;
  
  // Player info
  playerName: string;
  playerId: string | null;
  playerColor: number;
  
  // Aircraft state
  position: THREE.Vector3;
  rotation: THREE.Euler;
  velocity: number;
  throttle: number;
  
  // Multiplayer state
  roomCode: string | null;
  players: Map<string, Player>;
  connectionStatus: ConnectionStatus;
  playerCount: number;
  maxPlayers: number;
  
  // Physics and constants
  gravity: number;
  maxSpeed: number;
  minSpeed: number;
  turnRate: number;
  
  // Aircraft controls
  rollValue: number;
  pitchValue: number;
  yawValue: number;
  
  // Actions for game state
  startLoading: () => void;
  finishLoading: () => void;
  showMenu: () => void;
  showCreateRoom: () => void;
  showJoinRoom: () => void;
  startSinglePlayer: (name: string) => void;
  startMultiplayer: (roomCode: string, name: string, id: string, color: number) => void;
  pauseGame: () => void;
  resumeGame: () => void;
  exitGame: () => void;
  
  // Actions for aircraft controls
  setThrottle: (value: number) => void;
  setRoll: (value: number) => void;
  setPitch: (value: number) => void;
  setYaw: (value: number) => void;
  
  // Aircraft update functions
  updatePosition: (newPosition: THREE.Vector3) => void;
  updateRotation: (newRotation: THREE.Euler) => void;
  updateVelocity: (newVelocity: number) => void;
  
  // Multiplayer actions
  updateConnectionStatus: (status: ConnectionStatus) => void;
  updateRoomInfo: (playerCount: number, maxPlayers: number) => void;
  updatePlayersList: (playersArray: Player[]) => void;
  addPlayer: (player: Player) => void;
  updatePlayer: (id: string, data: Partial<Player>) => void;
  removePlayer: (id: string) => void;
}

export const useFlightSimulator = create<FlightSimulatorState>()(
  subscribeWithSelector((set, get) => ({
    // Game state
    phase: "loading",
    singlePlayer: false,
    
    // Player info
    playerName: "",
    playerId: null,
    playerColor: 0xff0000,
    
    // Aircraft state
    position: new THREE.Vector3(0, 100, 0),
    rotation: new THREE.Euler(0, 0, 0),
    velocity: 0,
    throttle: 0.5,
    
    // Multiplayer state
    roomCode: null,
    players: new Map(),
    connectionStatus: "disconnected",
    playerCount: 0,
    maxPlayers: 10,
    
    // Physics and constants
    gravity: 9.8,
    maxSpeed: 100,
    minSpeed: 20,
    turnRate: 0.03,
    
    // Aircraft controls
    rollValue: 0,
    pitchValue: 0,
    yawValue: 0,
    
    // Actions for game state
    startLoading: () => set({ phase: "loading" }),
    
    finishLoading: () => set({ phase: "menu" }),
    
    showMenu: () => set({ phase: "menu" }),
    
    showCreateRoom: () => set({ phase: "create" }),
    
    showJoinRoom: () => set({ phase: "join" }),
    
    startSinglePlayer: (name) => set({
      phase: "playing",
      singlePlayer: true,
      playerName: name,
      playerId: "local",
      playerColor: 0xff0000,
      position: new THREE.Vector3(0, 100, 0),
      rotation: new THREE.Euler(0, 0, 0),
      velocity: 30,
      throttle: 0.5,
      players: new Map(),
    }),
    
    startMultiplayer: (roomCode, name, id, color) => set({
      phase: "playing",
      singlePlayer: false,
      playerName: name,
      playerId: id,
      playerColor: color,
      roomCode: roomCode,
      position: new THREE.Vector3(0, 100, 0),
      rotation: new THREE.Euler(0, 0, 0),
      velocity: 30,
      throttle: 0.5,
    }),
    
    pauseGame: () => {
      const { phase } = get();
      if (phase === "playing") {
        set({ phase: "paused" });
      }
    },
    
    resumeGame: () => {
      const { phase } = get();
      if (phase === "paused") {
        set({ phase: "playing" });
      }
    },
    
    exitGame: () => set({
      phase: "menu",
      singlePlayer: false,
      roomCode: null,
      playerId: null,
      connectionStatus: "disconnected",
      players: new Map(),
    }),
    
    // Actions for aircraft controls
    setThrottle: (value) => {
      const { minSpeed, maxSpeed } = get();
      // Clamp throttle between 0 and 1
      const clampedThrottle = Math.max(0, Math.min(1, value));
      // Convert throttle to velocity
      const newVelocity = minSpeed + (maxSpeed - minSpeed) * clampedThrottle;
      
      set({
        throttle: clampedThrottle,
        velocity: newVelocity
      });
    },
    
    setRoll: (value) => set({ rollValue: value }),
    
    setPitch: (value) => set({ pitchValue: value }),
    
    setYaw: (value) => set({ yawValue: value }),
    
    // Aircraft update functions
    updatePosition: (newPosition) => set({ position: newPosition }),
    
    updateRotation: (newRotation) => set({ rotation: newRotation }),
    
    updateVelocity: (newVelocity) => set({ 
      velocity: Math.max(get().minSpeed, Math.min(get().maxSpeed, newVelocity)) 
    }),
    
    // Multiplayer actions
    updateConnectionStatus: (status) => set({ connectionStatus: status }),
    
    updateRoomInfo: (playerCount, maxPlayers) => set({ 
      playerCount, 
      maxPlayers 
    }),
    
    updatePlayersList: (playersArray) => {
      const playersMap = new Map();
      playersArray.forEach(player => {
        const position = player.position || { x: 0, y: 100, z: 0 };
        const rotation = player.rotation || { x: 0, y: 0, z: 0 };
        playersMap.set(player.id, {
          ...player,
          position: new THREE.Vector3(position.x, position.y, position.z),
          rotation: new THREE.Euler(rotation.x, rotation.y, rotation.z)
        });
      });
      
      set({ players: playersMap });
    },
    
    addPlayer: (player) => {
      set(state => {
        const updatedPlayers = new Map(state.players);
        const position = player.position || { x: 0, y: 100, z: 0 };
        const rotation = player.rotation || { x: 0, y: 0, z: 0 };
        updatedPlayers.set(player.id, {
          ...player,
          position: new THREE.Vector3(position.x, position.y, position.z),
          rotation: new THREE.Euler(rotation.x, rotation.y, rotation.z)
        });
        return { players: updatedPlayers };
      });
    },
    
    updatePlayer: (id, data) => {
      set(state => {
        if (!state.players.has(id)) return state;
        
        const updatedPlayers = new Map(state.players);
        const player = updatedPlayers.get(id)!;
        
        // Update position if provided
        if (data.position) {
          player.position.set(
            data.position.x,
            data.position.y,
            data.position.z
          );
        }
        
        // Update rotation if provided
        if (data.rotation) {
          player.rotation.set(
            data.rotation.x,
            data.rotation.y,
            data.rotation.z
          );
        }
        
        // Update velocity if provided
        if (data.velocity !== undefined) {
          player.velocity = data.velocity;
        }
        
        updatedPlayers.set(id, player);
        return { players: updatedPlayers };
      });
    },
    
    removePlayer: (id) => {
      set(state => {
        const updatedPlayers = new Map(state.players);
        updatedPlayers.delete(id);
        return { players: updatedPlayers };
      });
    }
  }))
);
