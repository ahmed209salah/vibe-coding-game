import { io, Socket } from "socket.io-client";
import { useFlightSimulator } from "./stores/useFlightSimulator";

// Use a fixed server URL since we're having issues with process.env
// For multiplayer mode - but handle connection errors gracefully
const SOCKET_SERVER_URL = window.location.hostname === 'localhost' 
  ? 'http://localhost:5000'
  : `${window.location.protocol}//${window.location.hostname}`;

// Flag to avoid repeated error messages
let hasShownConnectionError = false;

let socket: Socket | null = null;

// Initialize the socket connection
export const initializeSocket = (): Socket | null => {
  if (!socket) {
    try {
      socket = io(SOCKET_SERVER_URL, {
        reconnectionAttempts: 2,
        timeout: 5000,
        transports: ['websocket', 'polling'],
        autoConnect: true
      });
      
      // Handle connection errors more gracefully
      socket.on("connect_error", (error) => {
        if (!hasShownConnectionError) {
          console.log("Socket connection error (multiplayer unavailable):", error);
          hasShownConnectionError = true;
          
          // Notify any menu components about the error
          const event = new CustomEvent('socket-connection-error', { 
            detail: { message: "Unable to connect to multiplayer server" } 
          });
          window.dispatchEvent(event);
        }
      });
      
      socket.on("disconnect", (reason) => {
        console.log("Socket disconnected:", reason);
      });
      
      // Log successful connection
      socket.on("connect", () => {
        console.log("Socket connected successfully!");
        hasShownConnectionError = false;
      });
      
      setupSocketListeners(socket);
      console.log("Socket initialized with URL:", SOCKET_SERVER_URL);
    } catch (error) {
      console.error("Failed to initialize socket:", error);
      return null;
    }
  }
  return socket;
};

// Get the socket instance (creating it if needed)
export const getSocket = (): Socket | null => {
  return socket;
};

// Close the socket connection
export const closeSocket = (): void => {
  if (socket) {
    socket.disconnect();
    socket = null;
  }
};

// Create a new multiplayer room with custom code
export const createRoom = (playerName: string, roomCode: string): void => {
  if (!socket) initializeSocket();
  socket?.emit("createRoom", { name: playerName, roomCode });
};

// Join an existing multiplayer room
export const joinRoom = (roomCode: string, playerName: string): void => {
  if (!socket) initializeSocket();
  socket?.emit("joinRoom", { roomCode, name: playerName });
};

// Leave the current room
export const leaveRoom = (): void => {
  socket?.emit("leaveRoom");
};

// Update player state (position, rotation, velocity)
export const updatePlayerState = (data: any): void => {
  socket?.emit("updatePlayer", data);
};

// Setup event listeners for the socket
const setupSocketListeners = (socket: Socket): void => {
  const {
    startMultiplayer,
    updateConnectionStatus,
    updateRoomInfo,
    updatePlayer,
    addPlayer,
    removePlayer
  } = useFlightSimulator.getState();

  // Connection events
  socket.on("connect", () => {
    console.log("Connected to server");
    updateConnectionStatus("connected");
  });

  socket.on("disconnect", () => {
    console.log("Disconnected from server");
    updateConnectionStatus("disconnected");
  });

  socket.on("connect_error", (error) => {
    console.error("Connection error:", error);
    updateConnectionStatus("disconnected");
  });

  // Room events
  socket.on("roomCreated", ({ roomCode, playerId, playerName, playerColor }) => {
    console.log(`Room created: ${roomCode}`);
    startMultiplayer(roomCode, playerName, playerId, playerColor);
  });

  socket.on("roomJoined", ({ roomCode, playerId, playerName, playerColor, players }) => {
    console.log(`Joined room: ${roomCode}`);
    startMultiplayer(roomCode, playerName, playerId, playerColor);
    
    // Add all existing players
    players.forEach((player: any) => {
      if (player.id !== playerId) {
        addPlayer(player);
      }
    });
  });

  socket.on("playerCount", ({ count, maxPlayers }) => {
    updateRoomInfo(count, maxPlayers);
  });

  // Player events
  socket.on("playerJoined", (player) => {
    console.log(`Player joined: ${player.name}`);
    addPlayer(player);
  });

  socket.on("playerUpdated", (data) => {
    updatePlayer(data.id, data);
  });

  socket.on("playerLeft", ({ id }) => {
    console.log(`Player left: ${id}`);
    removePlayer(id);
  });

  // Error handling
  socket.on("error", ({ message }) => {
    console.error("Server error:", message);
    alert(`Error: ${message}`);
  });
};
