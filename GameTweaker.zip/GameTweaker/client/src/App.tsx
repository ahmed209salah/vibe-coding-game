import { Canvas } from "@react-three/fiber";
import { Suspense, useEffect, useState } from "react";
import { KeyboardControls } from "@react-three/drei";
import { useAudio } from "./lib/stores/useAudio";
import { useFlightSimulator } from "./lib/stores/useFlightSimulator";
import "@fontsource/inter";

// Import our game components
import { Environment } from "./components/Environment";
import { Aircraft } from "./components/Aircraft";
import { Lighting } from "./components/Lighting";
import { Controls } from "./components/Controls";
import { GameUI } from "./components/GameUI";
import { Menus } from "./components/Menus";
import { MultiplayerManager } from "./components/MultiplayerManager";

// Define control keys for the game
const controls = [
  { name: "throttleUp", keys: ["ArrowUp"] },
  { name: "throttleDown", keys: ["ArrowDown"] },
  { name: "rollLeft", keys: ["KeyA"] },
  { name: "rollRight", keys: ["KeyD"] },
  { name: "pitchUp", keys: ["KeyW"] },
  { name: "pitchDown", keys: ["KeyS"] },
  { name: "yawLeft", keys: ["ArrowLeft"] },
  { name: "yawRight", keys: ["ArrowRight"] },
];

// Main App component
function App() {
  const { phase, startLoading, finishLoading } = useFlightSimulator();
  const [showCanvas, setShowCanvas] = useState(false);
  const { setBackgroundMusic, setHitSound, setSuccessSound } = useAudio();

  // Initialize game and load assets
  useEffect(() => {
    startLoading();

    // We'll add sounds later when we fix the paths
    // For now, let's continue without audio to get the game working

    // Add a small delay to ensure everything is initialized
    setTimeout(() => {
      // Show the canvas once everything is loaded
      setShowCanvas(true);
      finishLoading();
      console.log("Game initialized successfully");
    }, 500);
  }, [startLoading, finishLoading]);

  return (
    <div style={{ width: '100vw', height: '100vh', position: 'relative', overflow: 'hidden' }}>
      {phase === 'loading' && (
        <div className="loading-screen">
          <div className="spinner"></div>
          <h1>3D Flight Simulator</h1>
          <p>Loading game assets...</p>
        </div>
      )}

      {showCanvas && (
        <KeyboardControls map={controls}>
          <Menus />

          {(phase === 'playing' || phase === 'paused') && (
            <>
              <Canvas
                shadows="basic"
                camera={{
                  position: [0, 110, 30],
                  fov: 75,
                  near: 1,
                  far: 5000
                }}
                gl={{
                  antialias: true,
                  powerPreference: "high-performance",
                  alpha: false,
                  stencil: false,
                  depth: true,
                  logarithmicDepthBuffer: false
                }}
                dpr={1}
              >
                <color attach="background" args={["#87CEEB"]} />

                {/* Lighting */}
                <Lighting />

                <Suspense fallback={null}>
                  {/* Environment (terrain, sky, etc) */}
                  <Environment />

                  {/* Player Aircraft */}
                  <Aircraft />

                  {/* Movement and physics controls */}
                  <Controls />

                  {/* Multiplayer players */}
                  <MultiplayerManager />
                </Suspense>
              </Canvas>
              <GameUI />
            </>
          )}
        </KeyboardControls>
      )}
    </div>
  );
}

export default App;