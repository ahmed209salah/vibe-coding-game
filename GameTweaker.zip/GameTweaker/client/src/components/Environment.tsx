
import { useTexture } from "@react-three/drei";
import * as THREE from "three";
import { useEffect } from "react";

export function Environment() {
  const textures = useTexture({
    ground: '/textures/grass.png',
    runway: '/textures/asphalt.png',
    sand: '/textures/sand.jpg',
  });

  useEffect(() => {
    Object.values(textures).forEach(texture => {
      if (texture) {
        texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
        texture.repeat.set(100, 100);
        texture.anisotropy = 16;
        texture.needsUpdate = true;
      }
    });
  }, [textures]);
  
  return (
    <group>
      {/* Terrain */}
      <mesh 
        rotation={[-Math.PI / 2, 0, 0]} 
        position={[0, -0.1, 0]}
        receiveShadow
        renderOrder={0}
      >
        <planeGeometry args={[5000, 5000, 100, 100]} />
        <meshStandardMaterial 
          map={textures.ground}
          roughness={0.7}
          metalness={0.2}
          envMapIntensity={1.5}
          depthWrite={true}
          transparent={false}
        />
      </mesh>
      
      {/* Sky dome */}
      <mesh renderOrder={-1}>
        <sphereGeometry args={[4000, 64, 64]} />
        <meshBasicMaterial color="#1E90FF" side={THREE.BackSide} fog={false} depthWrite={false} />
      </mesh>
      
      {/* Mountains */}
      {Array(20).fill(0).map((_, i) => {
        const angle = (i / 20) * Math.PI * 2;
        const dist = 2000 + (i * 50); // Fixed distance for stability
        const x = Math.cos(angle) * dist;
        const z = Math.sin(angle) * dist;
        const height = 300 + (i * 40); // Fixed height for stability
        
        return (
          <mesh 
            key={`mountain-${i}`}
            position={[x, 0, z]}
            castShadow
            receiveShadow
            renderOrder={1}
          >
            <coneGeometry args={[dist * 0.05, height, 16]} />
            <meshStandardMaterial 
              map={textures.sand}
              roughness={0.9}
              metalness={0.1}
              depthWrite={true}
              transparent={false}
            />
          </mesh>
        );
      })}

      {/* Runway */}
      <mesh
        rotation={[-Math.PI / 2, 0, 0]}
        position={[0, 0.01, 0]}
        receiveShadow
        renderOrder={2}
      >
        <planeGeometry args={[100, 1000, 10, 100]} />
        <meshStandardMaterial 
          map={textures.runway}
          roughness={0.8}
          metalness={0.2}
          depthWrite={true}
          transparent={false}
        />
      </mesh>
      
      {/* Runway markings */}
      <mesh
        rotation={[-Math.PI / 2, 0, 0]}
        position={[0, 0.02, 0]}
        receiveShadow
        renderOrder={3}
      >
        <planeGeometry args={[2, 1000, 1, 100]} />
        <meshStandardMaterial 
          color="#ffffff"
          roughness={0.4}
          metalness={0.1}
          depthWrite={true}
          transparent={false}
        />
      </mesh>
      
      {/* Buildings */}
      {Array(10).fill(0).map((_, i) => {
        const x = (i % 2 === 0 ? 60 : -60);
        const z = (i * 80) - 400;
        const size = 10 + (i * 1); // Fixed size for stability
        const height = 5 + (i * 2); // Fixed height for stability
        
        return (
          <mesh
            key={`building-${i}`}
            position={[x, height / 2, z]}
            castShadow
            receiveShadow
            renderOrder={4}
          >
            <boxGeometry args={[size, height, size]} />
            <meshStandardMaterial 
              color={`rgb(${120 + i * 10}, ${120 + i * 10}, ${120 + i * 10})`}
              roughness={0.7}
              metalness={0.3}
              depthWrite={true}
              transparent={false}
            />
          </mesh>
        );
      })}
    </group>
  );
}
