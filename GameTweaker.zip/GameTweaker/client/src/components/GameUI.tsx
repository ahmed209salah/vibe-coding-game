import { useEffect, useState } from "react";
import { useFlightSimulator } from "../lib/stores/useFlightSimulator";
import { useAudio } from "../lib/stores/useAudio";
import { leaveRoom } from "../lib/socket";

export function GameUI() {
  const { 
    phase,
    singlePlayer,
    playerName,
    roomCode,
    playerCount,
    maxPlayers,
    position,
    velocity,
    throttle,
    exitGame,
  } = useFlightSimulator();
  
  const { toggleMute, isMuted } = useAudio();
  const [showHUD, setShowHUD] = useState(true);
  
  // Toggle HUD with H key
  useEffect(() => {
    const handleKeyPress = (event: KeyboardEvent) => {
      if (event.code === 'KeyH') {
        setShowHUD(prev => !prev);
      }
      
      // Toggle sound with M key
      if (event.code === 'KeyM') {
        toggleMute();
      }
      
      // Exit with Escape key
      if (event.code === 'Escape') {
        // If in single player mode, just exit
        if (singlePlayer) {
          exitGame();
        } else {
          // In multiplayer, leave the room first
          leaveRoom();
          exitGame();
        }
      }
    };
    
    window.addEventListener('keydown', handleKeyPress);
    
    return () => {
      window.removeEventListener('keydown', handleKeyPress);
    };
  }, [singlePlayer]);
  
  // Format altitude to show in meters
  const altitude = Math.round(position.y);
  
  // Format speed in km/h
  const speed = Math.round(velocity * 3.6);
  
  // Only show UI when the game is playing or paused
  if (phase !== 'playing' && phase !== 'paused') {
    return null;
  }
  
  return (
    <div style={{ position: 'absolute', width: '100%', height: '100%', pointerEvents: 'none' }}>
      {showHUD && (
        <>
          {/* Main HUD */}
          <div className="game-info" style={{ display: 'block' }}>
            <h1>Flight Simulator</h1>
            <p className={singlePlayer ? 'status-solo' : 'status-multiplayer'}>
              {singlePlayer ? 'SOLO MODE' : 'MULTIPLAYER'}
            </p>
            <p>Use W/S to control speed, A/D to roll, Arrow keys to control elevation/direction</p>
            <p>H: Toggle HUD | M: Toggle Sound | ESC: Exit</p>
          </div>
          
          {/* Room information */}
          {!singlePlayer && roomCode && (
            <div className="room-info" style={{ display: 'block' }}>
              <div className="room-details">
                <p>Room: <span className="room-code">{roomCode}</span></p>
                <p>Players: <span className="player-count">{playerCount}</span> / <span>{maxPlayers}</span></p>
              </div>
            </div>
          )}
          
          {/* Flight instruments */}
          <div className="flight-instruments">
            <div style={{ marginBottom: '10px' }}>
              <div>Altitude: {altitude}m</div>
              <div>Speed: {speed} km/h</div>
              <div>Throttle: {Math.round(throttle * 100)}%</div>
            </div>
            <div className="throttle-gauge">
              <div 
                className={`throttle-gauge-fill ${throttle > 0.8 ? 'high' : ''}`} 
                style={{ width: `${throttle * 100}%` }} 
              />
            </div>
          </div>
          
          {/* Mute indicator */}
          <div className="sound-indicator">
            Sound: {isMuted ? 'OFF' : 'ON'}
          </div>
        </>
      )}
      
      {/* Exit game button always visible */}
      <button 
        id="exit-game-btn" 
        className="ui-button" 
        style={{ 
          display: 'block',
          pointerEvents: 'auto'
        }}
        onClick={() => {
          if (!singlePlayer) {
            leaveRoom();
          }
          exitGame();
        }}
      >
        Exit Game
      </button>
      
      {/* Pause overlay */}
      {phase === 'paused' && (
        <div className="pause-overlay">
          <h2>Game Paused</h2>
          <p>Press ESC to continue or exit</p>
        </div>
      )}
    </div>
  );
}
