import { useEffect, useRef } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import { useKeyboardControls } from "@react-three/drei";
import * as THREE from "three";
import { useFlightSimulator } from "../lib/stores/useFlightSimulator";
import { updatePlayerState } from "../lib/socket";

// Temporary ground level for collision detection
const GROUND_LEVEL = 0;

export function Controls() {
  // Access camera from Three.js
  const { camera } = useThree();
  
  // Create refs for camera following with smoother transitions
  const cameraPositionRef = useRef(new THREE.Vector3(0, 5, -10)); 
  const cameraLookAtRef = useRef(new THREE.Vector3(0, 0, 0));
  const prevPositionRef = useRef(new THREE.Vector3(0, 100, 0));
  const prevRotationRef = useRef(new THREE.Euler(0, 0, 0));
  
  const { 
    position, 
    rotation, 
    velocity, 
    throttle,
    gravity,
    turnRate,
    singlePlayer,
    phase,
    updatePosition,
    updateRotation,
    updateVelocity,
    setThrottle
  } = useFlightSimulator();
  
  // Get keyboard controls state using a different approach for better reliability
  const [subscribeKeys, getKeys] = useKeyboardControls();
  
  // Use effect hook to track component lifecycle
  useEffect(() => {
    // Log when controls component is mounted
    console.log("Controls component initialized");
    
    // Initialize previous position and rotation
    prevPositionRef.current.copy(position);
    prevRotationRef.current.copy(rotation);
    
    // Return cleanup function
    return () => {
      console.log("Controls component unmounted");
    };
  }, [position, rotation]);
  
  // Create direction vectors for aircraft motion
  const direction = new THREE.Vector3(0, 0, 1);
  const quaternion = new THREE.Quaternion();
  const tempVector = new THREE.Vector3();
  
  // Camera follow settings - reduced camera movement for stability
  const cameraDistance = 20;    // Distance behind aircraft (increased)
  const cameraHeight = 8;       // Height above aircraft (increased)
  const cameraSmoothing = 0.03; // Much smoother camera (reduced value)
  
  // Aircraft physics and controls
  useFrame((_, delta) => {
    // Only run if game is in playing phase
    if (phase !== 'playing') return;
    
    // Get current keyboard state - more reliable approach
    const controls = getKeys();
    
    // Debug output occasionally to avoid console spam
    if (Math.random() < 0.01) {
      console.log("Controls active:", { 
        throttleUp: controls.throttleUp ? "yes" : "no", 
        throttleDown: controls.throttleDown ? "yes" : "no", 
        rollLeft: controls.rollLeft ? "yes" : "no",
        rollRight: controls.rollRight ? "yes" : "no",
        pitchUp: controls.pitchUp ? "yes" : "no",
        pitchDown: controls.pitchDown ? "yes" : "no",
        position: position.toArray()
      });
    }
    
    // Update camera to follow aircraft with smoother transitions
    if (camera) {
      // Create a smoothed rotation that doesn't change as rapidly
      const smoothedRotation = new THREE.Euler(
        prevRotationRef.current.x + (rotation.x - prevRotationRef.current.x) * 0.05,
        prevRotationRef.current.y + (rotation.y - prevRotationRef.current.y) * 0.05,
        prevRotationRef.current.z + (rotation.z - prevRotationRef.current.z) * 0.05
      );
      
      // Update previous rotation for next frame
      prevRotationRef.current.copy(smoothedRotation);
      
      // Use smoothed position as well
      const smoothedPosition = new THREE.Vector3(
        prevPositionRef.current.x + (position.x - prevPositionRef.current.x) * 0.1,
        prevPositionRef.current.y + (position.y - prevPositionRef.current.y) * 0.1,
        prevPositionRef.current.z + (position.z - prevPositionRef.current.z) * 0.1
      );
      
      // Update previous position for next frame
      prevPositionRef.current.copy(smoothedPosition);
      
      // Calculate ideal camera position behind aircraft using smoothed values
      const idealOffset = new THREE.Vector3(0, cameraHeight, -cameraDistance);
      idealOffset.applyQuaternion(quaternion.setFromEuler(smoothedRotation));
      const idealPosition = new THREE.Vector3().copy(smoothedPosition).add(idealOffset);
      
      // Apply extra smoothing to camera position
      cameraPositionRef.current.lerp(idealPosition, cameraSmoothing);
      
      // Calculate look-at position (slightly ahead of aircraft)
      const lookAtOffset = new THREE.Vector3(0, 0, 10);
      lookAtOffset.applyQuaternion(quaternion.setFromEuler(smoothedRotation));
      cameraLookAtRef.current.lerp(smoothedPosition.clone().add(lookAtOffset), cameraSmoothing);
      
      // Update camera position and orientation
      camera.position.copy(cameraPositionRef.current);
      camera.lookAt(cameraLookAtRef.current);
    }
    
    // Handle throttle controls
    if (controls.throttleUp) {
      setThrottle(throttle + 0.01);
    }
    
    if (controls.throttleDown) {
      setThrottle(throttle - 0.01);
    }
    
    // Handle rotation controls
    const newRotation = rotation.clone();
    
    // Roll (rotate around Z axis)
    if (controls.rollLeft) {
      newRotation.z += turnRate;
    }
    
    if (controls.rollRight) {
      newRotation.z -= turnRate;
    }
    
    // Pitch (rotate around X axis)
    if (controls.pitchUp) {
      newRotation.x -= turnRate;
    }
    
    if (controls.pitchDown) {
      newRotation.x += turnRate;
    }
    
    // Yaw (rotate around Y axis)
    if (controls.yawLeft) {
      newRotation.y += turnRate;
    }
    
    if (controls.yawRight) {
      newRotation.y -= turnRate;
    }
    
    // Update rotation
    updateRotation(newRotation);
    
    // Calculate movement direction based on rotation
    quaternion.setFromEuler(rotation);
    direction.set(0, 0, 1).applyQuaternion(quaternion);
    
    // Apply velocity to position
    const scaledVelocity = velocity * delta;
    
    // Calculate new position
    tempVector.copy(direction).multiplyScalar(scaledVelocity);
    const newPosition = position.clone().add(tempVector);
    
    // Apply gravity based on aircraft orientation
    // The more level the aircraft, the less gravity affects it
    const levelness = Math.abs(Math.cos(rotation.z) * Math.cos(rotation.x));
    const gravityEffect = gravity * (1 - levelness) * delta;
    newPosition.y -= gravityEffect;
    
    // Prevent going below ground
    if (newPosition.y < GROUND_LEVEL + 0.5) {
      newPosition.y = GROUND_LEVEL + 0.5;
      // Crash logic would go here
    }
    
    // Update position
    updatePosition(newPosition);
    
    // If in multiplayer mode, send updates to the server
    if (!singlePlayer) {
      updatePlayerState({
        position: {
          x: newPosition.x,
          y: newPosition.y,
          z: newPosition.z
        },
        rotation: {
          x: newRotation.x,
          y: newRotation.y,
          z: newRotation.z
        },
        velocity
      });
    }
  });
  
  return null;
}
