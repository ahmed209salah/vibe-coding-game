import { useState, useEffect } from "react";
import { useFlightSimulator } from "../lib/stores/useFlightSimulator";
import { createRoom, joinRoom } from "../lib/socket";

export function Menus() {
  const { phase, showMenu, showCreateRoom, showJoinRoom, startSinglePlayer } = useFlightSimulator();
  
  const [playerName, setPlayerName] = useState("");
  const [roomCode, setRoomCode] = useState("");
  const [errorMessage, setErrorMessage] = useState(""); 
  const [isConnecting, setIsConnecting] = useState(false);
  
  // Handle menu navigation
  const handleBackToMenu = () => {
    setErrorMessage("");
    showMenu();
  };
  
  // Handle single player start
  const handleSinglePlayer = () => {
    // Default to "Pilot" if no name provided
    const name = playerName.trim() || "Pilot";
    startSinglePlayer(name);
  };
  
  const [customRoomCode, setCustomRoomCode] = useState("");

  // Handle create room with custom room code
  const handleCreateRoom = () => {
    setErrorMessage("");
    setIsConnecting(true);
    
    if (!customRoomCode.trim() || customRoomCode.length !== 6) {
      setErrorMessage("Please enter a valid 6-digit room code");
      setIsConnecting(false);
      return;
    }

    // Default to "Pilot" if no name provided
    const name = playerName.trim() || "Pilot";
    
    try {
      const timeoutId = setTimeout(() => {
        setErrorMessage("Unable to connect to multiplayer server. Please try single player mode instead.");
        setIsConnecting(false);
      }, 5000);
      
      // Attempt to create room with custom code
      createRoom(name, customRoomCode);
      
      setTimeout(() => {
        clearTimeout(timeoutId);
      }, 500);
    } catch (error) {
      setErrorMessage("Failed to create room. Please try single player mode.");
      setIsConnecting(false);
    }
  };
  
  // Handle join room with better error handling
  const handleJoinRoom = () => {
    setErrorMessage("");
    
    // Validate room code
    if (!roomCode.trim() || roomCode.length !== 6) {
      setErrorMessage("Please enter a valid 6-digit room code");
      return;
    }
    
    setIsConnecting(true);
    
    try {
      // Default to "Pilot" if no name provided
      const name = playerName.trim() || "Pilot";
      
      // Set a timeout in case socket connection fails
      const timeoutId = setTimeout(() => {
        setErrorMessage("Unable to connect to multiplayer server. Please try single player mode instead.");
        setIsConnecting(false);
      }, 5000);
      
      // Attempt to join room
      joinRoom(roomCode.trim(), name);
      
      // If successful, clear timeout
      setTimeout(() => {
        clearTimeout(timeoutId);
      }, 500);
    } catch (error) {
      setErrorMessage("Failed to join room. Please try single player mode.");
      setIsConnecting(false);
    }
  };
  
  // Load saved player name from local storage
  useEffect(() => {
    const savedName = localStorage.getItem("playerName");
    if (savedName) {
      setPlayerName(savedName);
    }
  }, []);
  
  // Save player name to local storage when it changes
  useEffect(() => {
    if (playerName.trim()) {
      localStorage.setItem("playerName", playerName);
    }
  }, [playerName]);
  
  // Listen for socket connection errors
  useEffect(() => {
    const handleSocketError = (event: CustomEvent) => {
      setErrorMessage(event.detail.message || "Multiplayer connection failed. Please try single player mode.");
      setIsConnecting(false);
    };
    
    window.addEventListener('socket-connection-error', handleSocketError as EventListener);
    
    return () => {
      window.removeEventListener('socket-connection-error', handleSocketError as EventListener);
    };
  }, []);
  
  // Don't render menu if game is playing
  if (phase === 'playing' || phase === 'paused') {
    return null;
  }
  
  return (
    <div className="menu-overlay">
      {/* Loading Screen */}
      {phase === 'loading' && (
        <div className="loading-screen">
          <div className="spinner"></div>
          <h1>3D Flight Simulator</h1>
          <p>Loading game assets...</p>
        </div>
      )}
      
      {/* Main Menu */}
      {phase === 'menu' && (
        <div className="menu-container">
          <h1>3D Flight Simulator</h1>
          <div className="form-group">
            <label htmlFor="player-name">Your Pilot Name</label>
            <input 
              type="text" 
              id="player-name" 
              value={playerName} 
              onChange={(e) => setPlayerName(e.target.value)} 
              placeholder="Enter your name" 
              maxLength={15}
            />
          </div>
          <button 
            id="create-room-btn" 
            className="menu-button"
            onClick={() => showCreateRoom()}
          >
            Create New Game
          </button>
          <button 
            id="join-room-btn" 
            className="menu-button"
            onClick={() => showJoinRoom()}
          >
            Join Game
          </button>
          <button 
            id="single-player-btn" 
            className="menu-button"
            onClick={handleSinglePlayer}
            style={{backgroundColor: 'var(--secondary-color)'}}
          >
            Single Player
          </button>
        </div>
      )}
      
      {/* Create Room Screen */}
      {phase === 'create' && (
        <div className="menu-container">
          <h1>Create New Game</h1>
          <div className="form-group">
            <label htmlFor="create-name">Your Pilot Name</label>
            <input 
              type="text" 
              id="create-name" 
              value={playerName} 
              onChange={(e) => setPlayerName(e.target.value)} 
              placeholder="Enter your name" 
              maxLength={15}
              disabled={isConnecting}
            />
          </div>
          <div className="form-group">
            <label htmlFor="create-room-code">Custom Room Code (6 digits)</label>
            <input 
              type="text" 
              id="create-room-code" 
              value={customRoomCode} 
              onChange={(e) => {
                const onlyNums = e.target.value.replace(/[^0-9]/g, '');
                setCustomRoomCode(onlyNums);
              }}
              placeholder="Enter 6-digit code" 
              maxLength={6}
              pattern="[0-9]*"
              disabled={isConnecting}
            />
          </div>
          
          {errorMessage && (
            <div className="error-message">
              {errorMessage}
            </div>
          )}
          
          <button 
            id="create-room-submit" 
            className={`menu-button ${isConnecting ? 'disabled' : ''}`}
            onClick={handleCreateRoom}
            disabled={isConnecting}
          >
            {isConnecting ? 'Connecting...' : 'Create Game'}
          </button>
          
          <button 
            id="back-from-create" 
            className="menu-button secondary"
            onClick={handleBackToMenu}
            disabled={isConnecting}
          >
            Back
          </button>
          
          <button 
            id="single-player-from-create" 
            className="menu-button alternative"
            onClick={handleSinglePlayer}
            style={{marginTop: '20px', backgroundColor: 'var(--secondary-color)'}}
          >
            Try Single Player
          </button>
        </div>
      )}
      
      {/* Join Room Screen */}
      {phase === 'join' && (
        <div className="menu-container">
          <h1>Join Game</h1>
          <div className="form-group">
            <label htmlFor="room-code">Room Code (6 digits)</label>
            <input 
              type="text" 
              id="room-code" 
              value={roomCode} 
              onChange={(e) => {
                const onlyNums = e.target.value.replace(/[^0-9]/g, '');
                setRoomCode(onlyNums);
              }}
              placeholder="Enter 6-digit code" 
              maxLength={6}
              pattern="[0-9]*"
              disabled={isConnecting}
            />
          </div>
          <div className="form-group">
            <label htmlFor="join-name">Your Pilot Name</label>
            <input 
              type="text" 
              id="join-name" 
              value={playerName} 
              onChange={(e) => setPlayerName(e.target.value)} 
              placeholder="Enter your name" 
              maxLength={15}
              disabled={isConnecting}
            />
          </div>
          
          {errorMessage && (
            <div className="error-message">
              {errorMessage}
            </div>
          )}
          
          <button 
            id="join-room-submit" 
            className={`menu-button ${isConnecting ? 'disabled' : ''}`}
            onClick={handleJoinRoom}
            disabled={isConnecting}
          >
            {isConnecting ? 'Connecting...' : 'Join Game'}
          </button>
          
          <button 
            id="back-from-join" 
            className="menu-button secondary"
            onClick={handleBackToMenu}
            disabled={isConnecting}
          >
            Back
          </button>
          
          <button 
            id="single-player-from-join" 
            className="menu-button alternative"
            onClick={handleSinglePlayer}
            style={{marginTop: '20px', backgroundColor: 'var(--secondary-color)'}}
          >
            Try Single Player
          </button>
        </div>
      )}
    </div>
  );
}
