import { create } from 'zustand';

interface ControlsState {
  // Control inputs (-1 to 1 range)
  pitchControl: number;
  rollControl: number;
  yawControl: number;
  throttleControl: number;
  
  // Control settings
  invertYAxis: boolean;
  sensitivity: number;
  
  // Methods
  setPitchControl: (value: number) => void;
  setRollControl: (value: number) => void;
  setYawControl: (value: number) => void;
  setThrottleControl: (value: number) => void;
  setInvertYAxis: (invert: boolean) => void;
  setSensitivity: (sensitivity: number) => void;
}

export const useControlsStore = create<ControlsState>((set) => ({
  // Initial control inputs
  pitchControl: 0,
  rollControl: 0,
  yawControl: 0,
  throttleControl: 0,
  
  // Initial settings
  invertYAxis: false,
  sensitivity: 1.0,
  
  // Methods
  setPitchControl: (value) => set({
    pitchControl: Math.max(-1, Math.min(1, value))
  }),
  setRollControl: (value) => set({
    rollControl: Math.max(-1, Math.min(1, value))
  }),
  setYawControl: (value) => set({
    yawControl: Math.max(-1, Math.min(1, value))
  }),
  setThrottleControl: (value) => set({
    throttleControl: Math.max(0, Math.min(1, value))
  }),
  setInvertYAxis: (invert) => set({ invertYAxis: invert }),
  setSensitivity: (sensitivity) => set({
    sensitivity: Math.max(0.1, Math.min(2.0, sensitivity))
  }),
}));