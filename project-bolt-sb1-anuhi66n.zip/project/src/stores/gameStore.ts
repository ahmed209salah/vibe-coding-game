import { create } from 'zustand';

interface GameState {
  // Aircraft state
  position: number[];
  rotation: number[];
  altitude: number;
  speed: number;
  fuel: number;
  damage: number;
  
  // Environment
  timeOfDay: number; // 0-24 hours
  weather: 'clear' | 'cloudy' | 'rainy' | 'stormy';
  
  // Game state
  paused: boolean;
  score: number;
  currentMission?: string;
  achievements: string[];
  
  // Methods
  updatePosition: (position: number[]) => void;
  updateRotation: (rotation: number[]) => void;
  updateAltitude: (altitude: number) => void;
  updateSpeed: (speed: number) => void;
  updateFuel: (fuel: number) => void;
  updateDamage: (damage: number) => void;
  setTimeOfDay: (time: number) => void;
  setWeather: (weather: 'clear' | 'cloudy' | 'rainy' | 'stormy') => void;
  setPaused: (paused: boolean) => void;
  addScore: (points: number) => void;
  setCurrentMission: (mission?: string) => void;
  addAchievement: (achievement: string) => void;
}

export const useGameStore = create<GameState>((set) => ({
  // Initial aircraft state
  position: [0, 100, 0],
  rotation: [0, 0, 0],
  altitude: 100,
  speed: 0,
  fuel: 100,
  damage: 0,
  
  // Initial environment
  timeOfDay: 12, // Noon
  weather: 'clear',
  
  // Initial game state
  paused: false,
  score: 0,
  achievements: [],
  
  // Methods
  updatePosition: (position) => set({ position }),
  updateRotation: (rotation) => set({ rotation }),
  updateAltitude: (altitude) => set({ altitude }),
  updateSpeed: (speed) => set({ speed }),
  updateFuel: (fuel) => set({ fuel: Math.max(0, Math.min(100, fuel)) }),
  updateDamage: (damage) => set({ damage: Math.max(0, Math.min(100, damage)) }),
  setTimeOfDay: (time) => set({ timeOfDay: time % 24 }),
  setWeather: (weather) => set({ weather }),
  setPaused: (paused) => set({ paused }),
  addScore: (points) => set((state) => ({ score: state.score + points })),
  setCurrentMission: (mission) => set({ currentMission: mission }),
  addAchievement: (achievement) => set((state) => ({
    achievements: [...state.achievements, achievement]
  })),
}));