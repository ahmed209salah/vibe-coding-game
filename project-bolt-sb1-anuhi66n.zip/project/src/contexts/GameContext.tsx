import { createContext, useContext, ReactNode, useState, useEffect } from 'react';
import { useGameStore } from '../stores/gameStore';
import { playSound, stopSound } from '../utils/audio';

interface GameContextType {
  isLoading: boolean;
  loadingProgress: number;
  gameOver: boolean;
  aircraftType: string;
  showTutorial: boolean;
  
  startGame: () => void;
  endGame: () => void;
  restartGame: () => void;
  setAircraftType: (aircraftType: string) => void;
  setShowTutorial: (show: boolean) => void;
}

const GameContext = createContext<GameContextType | null>(null);

export const useGame = () => {
  const context = useContext(GameContext);
  if (!context) {
    throw new Error('useGame must be used within a GameProvider');
  }
  return context;
};

export const GameProvider = ({ children }: { children: ReactNode }) => {
  const [isLoading, setIsLoading] = useState(true);
  const [loadingProgress, setLoadingProgress] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [aircraftType, setAircraftType] = useState('fighter');
  const [showTutorial, setShowTutorial] = useState(true);
  
  const { setPaused, updateFuel, updateDamage, setTimeOfDay, setWeather } = useGameStore();
  
  // Simulate assets loading
  useEffect(() => {
    if (isLoading) {
      const interval = setInterval(() => {
        setLoadingProgress((prev) => {
          const newProgress = prev + Math.random() * 10;
          if (newProgress >= 100) {
            clearInterval(interval);
            setTimeout(() => setIsLoading(false), 500);
            return 100;
          }
          return newProgress;
        });
      }, 200);
      
      return () => clearInterval(interval);
    }
  }, [isLoading]);
  
  // Handle fuel consumption timer
  useEffect(() => {
    if (!isLoading && !gameOver) {
      const interval = setInterval(() => {
        updateFuel((prev: number) => prev - 0.01);
      }, 1000);
      
      return () => clearInterval(interval);
    }
  }, [isLoading, gameOver, updateFuel]);
  
  // Game over condition
  useEffect(() => {
    const unsubscribe = useGameStore.subscribe(
      (state) => {
        if (state.fuel <= 0 || state.damage >= 100) {
          setGameOver(true);
          setPaused(true);
          playSound('gameOver');
        }
      }
    );
    
    return () => unsubscribe();
  }, [setPaused]);
  
  const startGame = () => {
    setIsLoading(true);
    setLoadingProgress(0);
    setGameOver(false);
    // Reset game state
    updateFuel(100);
    updateDamage(0);
    setTimeOfDay(12);
    setWeather('clear');
    setPaused(false);
    playSound('gameStart');
  };
  
  const endGame = () => {
    setGameOver(true);
    setPaused(true);
    stopSound('engine');
    playSound('gameOver');
  };
  
  const restartGame = () => {
    startGame();
  };
  
  const value = {
    isLoading,
    loadingProgress,
    gameOver,
    aircraftType,
    showTutorial,
    startGame,
    endGame,
    restartGame,
    setAircraftType,
    setShowTutorial,
  };
  
  return <GameContext.Provider value={value}>{children}</GameContext.Provider>;
};