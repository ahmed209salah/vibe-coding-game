import React, { useState } from 'react';
import GameView from './components/GameView';
import MainMenu from './components/UI/MainMenu';
import { GameProvider } from './contexts/GameContext';
import './App.css';

function App() {
  const [gameStarted, setGameStarted] = useState(false);
  
  return (
    <GameProvider>
      <div className="h-screen w-screen overflow-hidden bg-slate-900">
        {gameStarted ? (
          <GameView />
        ) : (
          <MainMenu onStartGame={() => setGameStarted(true)} />
        )}
      </div>
    </GameProvider>
  );
}

export default App;