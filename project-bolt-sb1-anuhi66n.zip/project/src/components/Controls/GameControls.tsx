import React, { useEffect } from 'react';
import { useControlsStore } from '../../stores/controlsStore';
import { useGameStore } from '../../stores/gameStore';
import { Gamepad, Keyboard } from 'lucide-react';

const GameControls: React.FC = () => {
  const { 
    setPitchControl,
    setRollControl, 
    setYawControl, 
    setThrottleControl,
    pitchControl,
    rollControl,
    yawControl,
    throttleControl 
  } = useControlsStore();
  
  const { paused, setPaused } = useGameStore();

  // Handle keyboard input
  useEffect(() => {
    const keys = new Set();
    
    const keyDownHandler = (e: KeyboardEvent) => {
      keys.add(e.code);
      
      // Handle special keys
      if (e.code === 'Escape') {
        setPaused(!paused);
      }
      
      updateControls();
    };
    
    const keyUpHandler = (e: KeyboardEvent) => {
      keys.delete(e.code);
      updateControls();
    };
    
    const updateControls = () => {
      // Pitch control (up/down)
      if (keys.has('ArrowUp') || keys.has('KeyW')) {
        setPitchControl(-1);
      } else if (keys.has('ArrowDown') || keys.has('KeyS')) {
        setPitchControl(1);
      } else {
        setPitchControl(0);
      }
      
      // Roll control (left/right banking)
      if (keys.has('KeyQ')) {
        setRollControl(-1);
      } else if (keys.has('KeyE')) {
        setRollControl(1);
      } else {
        setRollControl(0);
      }
      
      // Yaw control (left/right turning)
      if (keys.has('ArrowLeft') || keys.has('KeyA')) {
        setYawControl(-1);
      } else if (keys.has('ArrowRight') || keys.has('KeyD')) {
        setYawControl(1);
      } else {
        setYawControl(0);
      }
      
      // Throttle control
      if (keys.has('ShiftLeft') || keys.has('ShiftRight')) {
        setThrottleControl(Math.min(throttleControl + 0.01, 1));
      } else if (keys.has('ControlLeft') || keys.has('ControlRight')) {
        setThrottleControl(Math.max(throttleControl - 0.01, 0));
      }
    };
    
    window.addEventListener('keydown', keyDownHandler);
    window.addEventListener('keyup', keyUpHandler);
    
    // Set up animation frame for continuous updates
    const interval = setInterval(updateControls, 16);
    
    return () => {
      window.removeEventListener('keydown', keyDownHandler);
      window.removeEventListener('keyup', keyUpHandler);
      clearInterval(interval);
    };
  }, [paused, throttleControl, setPitchControl, setRollControl, setYawControl, setThrottleControl, setPaused]);

  // Mouse controls for touch devices
  useEffect(() => {
    let touchActive = false;
    let lastX = 0;
    let lastY = 0;
    
    const handleTouchStart = (e: TouchEvent) => {
      touchActive = true;
      lastX = e.touches[0].clientX;
      lastY = e.touches[0].clientY;
    };
    
    const handleTouchMove = (e: TouchEvent) => {
      if (!touchActive) return;
      
      const touchX = e.touches[0].clientX;
      const touchY = e.touches[0].clientY;
      
      const deltaX = touchX - lastX;
      const deltaY = touchY - lastY;
      
      // Map touch movement to control inputs
      setRollControl(deltaX / 50);
      setPitchControl(-deltaY / 50);
      
      lastX = touchX;
      lastY = touchY;
    };
    
    const handleTouchEnd = () => {
      touchActive = false;
      setRollControl(0);
      setPitchControl(0);
    };
    
    window.addEventListener('touchstart', handleTouchStart);
    window.addEventListener('touchmove', handleTouchMove);
    window.addEventListener('touchend', handleTouchEnd);
    
    return () => {
      window.removeEventListener('touchstart', handleTouchStart);
      window.removeEventListener('touchmove', handleTouchMove);
      window.removeEventListener('touchend', handleTouchEnd);
    };
  }, [setPitchControl, setRollControl]);

  return (
    <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 glass-panel p-4 rounded-lg z-10">
      <div className="flex items-center justify-center gap-6 text-white">
        <div className="flex flex-col items-center">
          <Keyboard size={24} className="mb-2" />
          <p className="text-sm">W,A,S,D: Movement</p>
          <p className="text-sm">Q,E: Roll</p>
          <p className="text-sm">Shift: Throttle Up</p>
          <p className="text-sm">Ctrl: Throttle Down</p>
          <p className="text-sm">ESC: Pause</p>
        </div>
        <div className="flex flex-col items-center">
          <Gamepad size={24} className="mb-2" />
          <p className="text-sm">Left Stick: Pitch/Roll</p>
          <p className="text-sm">Right Stick: Yaw</p>
          <p className="text-sm">Triggers: Throttle</p>
        </div>
      </div>
    </div>
  );
};

export default GameControls;