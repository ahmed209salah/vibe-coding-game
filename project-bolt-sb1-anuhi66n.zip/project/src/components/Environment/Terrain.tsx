import React, { useMemo } from 'react';
import * as THREE from 'three';
import { usePlane } from '@react-three/cannon';
import { useTexture } from '@react-three/drei';

import { generateTerrain } from '../../utils/terrainGenerator';

const Terrain = () => {
  // Generate terrain geometry
  const { geometry, heightMap } = useMemo(() => generateTerrain(128, 128, 500, 200), []);
  
  // Load textures
  const [
    grassTexture,
    rockTexture,
    snowTexture,
    sandTexture
  ] = useTexture([
    'https://images.pexels.com/photos/413195/pexels-photo-413195.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    'https://images.pexels.com/photos/220201/pexels-photo-220201.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    'https://images.pexels.com/photos/1996063/pexels-photo-1996063.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    'https://images.pexels.com/photos/1939485/pexels-photo-1939485.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  ]);

  // Set up texture properties
  [grassTexture, rockTexture, snowTexture, sandTexture].forEach(texture => {
    texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
    texture.repeat.set(32, 32);
  });

  // Create material with blended textures based on height
  const material = useMemo(() => {
    return new THREE.MeshStandardMaterial({
      map: grassTexture,
      displacementMap: heightMap,
      displacementScale: 100,
      metalness: 0.1,
      roughness: 0.8,
      vertexColors: true
    });
  }, [grassTexture, heightMap]);

  // Color the terrain based on height
  useMemo(() => {
    if (geometry) {
      const colors = [];
      const positions = geometry.getAttribute('position');
      
      for (let i = 0; i < positions.count; i++) {
        const y = positions.getY(i);
        
        // Apply different colors based on height
        if (y > 150) {
          // Snow
          colors.push(0.95, 0.95, 0.95);
        } else if (y > 80) {
          // Rock
          colors.push(0.5, 0.5, 0.5);
        } else if (y > 5) {
          // Grass
          colors.push(0.2, 0.5, 0.2);
        } else {
          // Sand/water
          colors.push(0.76, 0.7, 0.5);
        }
      }
      
      geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
    }
  }, [geometry]);

  // Add physics to the terrain
  const [ref] = usePlane(() => ({
    rotation: [-Math.PI / 2, 0, 0],
    position: [0, 0, 0],
    type: 'Static',
  }));

  // Create water plane
  const waterGeometry = new THREE.PlaneGeometry(10000, 10000);
  const waterMaterial = new THREE.MeshStandardMaterial({
    color: '#0066aa',
    metalness: 0.6,
    roughness: 0.2,
    transparent: true,
    opacity: 0.8,
  });

  return (
    <>
      <mesh ref={ref as any} receiveShadow geometry={geometry} material={material} />
      <mesh 
        rotation={[-Math.PI / 2, 0, 0]} 
        position={[0, 2, 0]} 
        geometry={waterGeometry} 
        material={waterMaterial} 
      />
    </>
  );
};

export default Terrain;