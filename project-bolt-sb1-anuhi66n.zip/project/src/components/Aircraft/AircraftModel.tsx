import React, { useRef, useEffect } from 'react';
import { useGLTF } from '@react-three/drei';
import { useFrame } from '@react-three/fiber';
import { useBox } from '@react-three/cannon';
import * as THREE from 'three';

import { useGameStore } from '../../stores/gameStore';
import { useControlsStore } from '../../stores/controlsStore';
import { playSound } from '../../utils/audio';

// Using a simple aircraft model for the prototype
const MODEL_URL = 'https://vazxmixjsiawhamofees.supabase.co/storage/v1/object/public/models/low-poly-spaceship/model.gltf';

const AircraftModel = ({ position = [0, 100, 0] }) => {
  const { scene } = useGLTF(MODEL_URL);
  const aircraftRef = useRef();
  const engineSoundRef = useRef(null);
  
  const {
    pitch, yaw, roll, throttle, 
    updatePosition, updateRotation, updateAltitude, updateSpeed
  } = useGameStore();
  
  const { pitchControl, rollControl, yawControl, throttleControl } = useControlsStore();

  // Simple physics for the aircraft
  const [ref, api] = useBox(() => ({
    mass: 1000,
    position,
    rotation: [0, 0, 0],
    linearDamping: 0.95,
    angularDamping: 0.95,
    type: 'Dynamic',
  }));

  // Connect the 3D model to the physics body
  useEffect(() => {
    if (aircraftRef.current && scene) {
      // Clone and scale the model
      const model = scene.clone();
      model.scale.set(0.5, 0.5, 0.5); // Reduced scale to make the aircraft more visible
      model.rotation.y = Math.PI; // Facing forward
      
      // Clear any existing children
      while (aircraftRef.current.children.length) {
        aircraftRef.current.remove(aircraftRef.current.children[0]);
      }
      
      // Add the new model
      aircraftRef.current.add(model);
    }
    
    // Start engine sound
    engineSoundRef.current = playSound('engine', { loop: true, volume: 0.5 });
    
    return () => {
      // Stop engine sound when component unmounts
      if (engineSoundRef.current) {
        // Stop sound logic would go here
      }
    };
  }, [scene]);

  // Update aircraft physics based on controls
  useFrame((_, delta) => {
    if (!ref.current) return;
    
    // Calculate forces based on controls
    const thrustForce = new THREE.Vector3(0, 0, -throttleControl * 50000 * delta);
    thrustForce.applyQuaternion(ref.current.quaternion);
    
    // Apply lift based on speed and angle of attack
    const liftForce = new THREE.Vector3(0, throttleControl * 40000 * delta, 0);
    liftForce.applyQuaternion(ref.current.quaternion);
    
    // Apply forces to the aircraft
    api.applyForce(thrustForce.toArray(), [0, 0, 0]);
    api.applyForce(liftForce.toArray(), [0, 0, 0]);
    
    // Apply torque for rotation
    api.applyTorque([
      pitchControl * 10000 * delta,
      yawControl * 8000 * delta,
      -rollControl * 15000 * delta
    ]);
    
    // Get current position and rotation
    const position = new THREE.Vector3();
    const quaternion = new THREE.Quaternion();
    const euler = new THREE.Euler();
    
    ref.current.getWorldPosition(position);
    ref.current.getWorldQuaternion(quaternion);
    euler.setFromQuaternion(quaternion);
    
    // Update game state
    updatePosition([position.x, position.y, position.z]);
    updateRotation([euler.x, euler.y, euler.z]);
    updateAltitude(position.y);
    
    // Calculate speed from velocity
    const velocity = new THREE.Vector3();
    api.velocity.copy(velocity);
    const speed = Math.sqrt(velocity.x**2 + velocity.y**2 + velocity.z**2);
    updateSpeed(speed * 3.6); // Convert to km/h
    
    // Update engine sound based on throttle
    if (engineSoundRef.current) {
      // Update sound volume/pitch logic would go here
    }
  });

  return (
    <group ref={ref}>
      <group ref={aircraftRef} />
    </group>
  );
};

export default AircraftModel;