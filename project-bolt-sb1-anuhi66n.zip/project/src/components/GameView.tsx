import React, { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { Sky, Cloud, Stars, Environment, PerspectiveCamera } from '@react-three/drei';
import { Physics } from '@react-three/cannon';

import LoadingScreen from './UI/LoadingScreen';
import HUD from './UI/HUD';
import GameControls from './Controls/GameControls';
import AircraftModel from './Aircraft/AircraftModel';
import Terrain from './Environment/Terrain';
import { useGameStore } from '../stores/gameStore';

const GameView: React.FC = () => {
  const { timeOfDay, weather } = useGameStore(state => ({
    timeOfDay: state.timeOfDay,
    weather: state.weather
  }));

  // Calculate sun position based on time of day (0-24)
  const sunPosition = [
    Math.cos((timeOfDay / 24) * Math.PI * 2) * 10,
    Math.sin((timeOfDay / 24) * Math.PI * 2) * 10,
    0
  ];
  
  const isCloudy = weather === 'cloudy' || weather === 'stormy';
  const isNight = timeOfDay < 6 || timeOfDay > 19;

  return (
    <div className="w-full h-full relative">
      <Canvas shadows>
        <Suspense fallback={null}>
          <PerspectiveCamera makeDefault position={[0, 10, -20]} fov={75} />
          
          <ambientLight intensity={isNight ? 0.2 : 0.5} />
          <directionalLight 
            position={sunPosition as [number, number, number]} 
            intensity={isNight ? 0.2 : 1.5} 
            castShadow 
          />
          
          {!isNight && (
            <Sky 
              distance={450000} 
              sunPosition={sunPosition as [number, number, number]} 
              inclination={0.5} 
              azimuth={0.25}
              turbidity={isCloudy ? 10 : 5}
              rayleigh={isCloudy ? 3 : 1}
            />
          )}
          
          {isNight && <Stars radius={100} depth={50} count={5000} factor={4} />}
          
          {isCloudy && (
            <>
              <Cloud position={[0, 100, -10]} speed={0.2} opacity={0.7} />
              <Cloud position={[-50, 100, 10]} speed={0.1} opacity={0.8} />
              <Cloud position={[50, 100, 0]} speed={0.3} opacity={0.6} />
            </>
          )}
          
          <Environment preset={isNight ? "night" : "sunset"} />
          
          <Physics gravity={[0, -9.81, 0]}>
            <AircraftModel position={[0, 100, 0]} />
            <Terrain />
          </Physics>
        </Suspense>
      </Canvas>
      
      <GameControls />
      <HUD />
      <LoadingScreen />
    </div>
  );
};

export default GameView;