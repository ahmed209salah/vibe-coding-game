import React from 'react';
import { useGameStore } from '../../stores/gameStore';
import { 
  Plane, Compass, Gauge, Wind, Droplet, 
  Thermometer, Sun, Clock, BarChart3 
} from 'lucide-react';

const HUD: React.FC = () => {
  const { 
    altitude, 
    speed, 
    fuel, 
    damage, 
    timeOfDay, 
    weather,
    rotation,
    score,
    paused,
    currentMission
  } = useGameStore();
  
  // Format altitude to show comma separators
  const formattedAltitude = altitude.toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  
  // Format speed to show only integers
  const formattedSpeed = Math.round(speed);
  
  // Convert rotation to heading (0-360 degrees)
  const headingDegrees = ((Math.atan2(
    Math.sin(rotation[1]), 
    Math.cos(rotation[1])
  ) * 180 / Math.PI) + 360) % 360;
  
  // Format heading to show 3 digits with leading zeros
  const formattedHeading = headingDegrees.toFixed(0).padStart(3, '0');
  
  // Format time as HH:MM
  const hours = Math.floor(timeOfDay);
  const minutes = Math.floor((timeOfDay - hours) * 60);
  const formattedTime = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;

  // Weather icon based on current weather
  const getWeatherIcon = () => {
    switch (weather) {
      case 'cloudy':
        return <Cloud size={22} />;
      case 'rainy':
        return <CloudRain size={22} />;
      case 'stormy':
        return <CloudLightning size={22} />;
      default:
        return <Sun size={22} />;
    }
  };
  
  if (paused) {
    return (
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="glass-panel p-8 rounded-lg z-30 text-center">
          <h1 className="text-4xl text-white font-bold mb-4 aircraft-panel">PAUSED</h1>
          <p className="text-lg text-white mb-8">Press ESC to resume</p>
          <div className="flex items-center justify-center">
            <div className="bg-indigo-500 px-6 py-3 rounded-md text-white font-semibold hover:bg-indigo-600 transition-colors cursor-pointer">
              Resume
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="absolute inset-0 pointer-events-none">
      {/* Top Bar */}
      <div className="absolute top-6 left-1/2 transform -translate-x-1/2 glass-panel px-6 py-2 rounded-full z-10 flex items-center gap-6">
        <div className="flex items-center gap-2">
          <Clock size={18} className="text-blue-400" />
          <span className="text-white">{formattedTime}</span>
        </div>
        <div className="flex items-center gap-2">
          {getWeatherIcon()}
          <span className="text-white capitalize">{weather}</span>
        </div>
        <div className="flex items-center gap-2">
          <BarChart3 size={18} className="text-green-400" />
          <span className="text-white">{score.toLocaleString()}</span>
        </div>
      </div>
      
      {/* Mission Notification */}
      {currentMission && (
        <div className="absolute top-20 left-1/2 transform -translate-x-1/2 glass-panel px-6 py-3 rounded-lg z-10 flex items-center gap-4">
          <div className="w-3 h-3 bg-yellow-400 rounded-full pulse"></div>
          <span className="text-white text-lg">{currentMission}</span>
        </div>
      )}
      
      {/* Main HUD Elements */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 glass-panel p-5 rounded-lg z-10 flex items-center gap-8 aircraft-panel">
        {/* Altitude Indicator */}
        <div className="flex flex-col items-center">
          <div className="instrument w-24 h-24 flex flex-col items-center justify-center relative">
            <div className="absolute inset-0 flex items-center justify-center">
              <div 
                className="altitude-indicator w-1 h-16 rounded-full indicator absolute"
                style={{ transform: `rotate(${(altitude / 10000) * 360}deg)` }}
              />
            </div>
            <Plane size={16} className="text-white absolute" />
            <div className="text-xl text-white mt-6">{formattedAltitude}</div>
          </div>
          <div className="text-blue-400 mt-1 text-sm">ALTITUDE</div>
        </div>
        
        {/* Speed Indicator */}
        <div className="flex flex-col items-center">
          <div className="instrument w-24 h-24 flex flex-col items-center justify-center relative">
            <div className="absolute inset-0 flex items-center justify-center">
              <div 
                className="speed-indicator w-1 h-16 rounded-full indicator absolute"
                style={{ transform: `rotate(${(speed / 300) * 360}deg)` }}
              />
            </div>
            <Gauge size={16} className="text-white absolute" />
            <div className="text-xl text-white mt-6">{formattedSpeed}</div>
          </div>
          <div className="text-orange-400 mt-1 text-sm">SPEED</div>
        </div>
        
        {/* Heading Indicator */}
        <div className="flex flex-col items-center">
          <div className="instrument w-24 h-24 flex flex-col items-center justify-center relative">
            <div className="absolute inset-0 flex items-center justify-center">
              <div 
                className="heading-indicator w-1 h-16 rounded-full indicator absolute"
                style={{ transform: `rotate(${headingDegrees}deg)` }}
              />
            </div>
            <Compass size={16} className="text-white absolute" />
            <div className="text-xl text-white mt-6">{formattedHeading}°</div>
          </div>
          <div className="text-green-400 mt-1 text-sm">HEADING</div>
        </div>
        
        {/* Fuel Gauge */}
        <div className="flex flex-col items-center">
          <div className="h-24 w-10 bg-gray-800 rounded-lg overflow-hidden border border-gray-700 relative">
            <div 
              className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-blue-600 to-blue-400 rounded-b-lg transition-all duration-300"
              style={{ height: `${fuel}%` }}
            />
            <div className="absolute inset-0 flex items-center justify-center">
              <Droplet size={16} className="text-white" />
            </div>
          </div>
          <div className="text-blue-400 mt-1 text-sm">FUEL</div>
        </div>
        
        {/* Damage Indicator */}
        <div className="flex flex-col items-center">
          <div className="h-24 w-10 bg-gray-800 rounded-lg overflow-hidden border border-gray-700 relative">
            <div 
              className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-red-600 to-red-400 rounded-b-lg transition-all duration-300"
              style={{ height: `${damage}%` }}
            />
            <div className="absolute inset-0 flex items-center justify-center">
              <Thermometer size={16} className="text-white" />
            </div>
          </div>
          <div className="text-red-400 mt-1 text-sm">DAMAGE</div>
        </div>
      </div>
    </div>
  );
};

// Custom icon components
const Cloud = ({ size }: { size: number }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    width={size} 
    height={size} 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className="text-gray-300"
  >
    <path d="M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z"/>
  </svg>
);

const CloudRain = ({ size }: { size: number }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    width={size} 
    height={size} 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className="text-blue-300"
  >
    <path d="M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z"/>
    <path d="M11 17.5a1 1 0 1 0-2 0 1 1 0 0 0 2 0Z"/>
    <path d="M14 17.5a1 1 0 1 0-2 0 1 1 0 0 0 2 0Z"/>
    <path d="M17 17.5a1 1 0 1 0-2 0 1 1 0 0 0 2 0Z"/>
  </svg>
);

const CloudLightning = ({ size }: { size: number }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    width={size} 
    height={size} 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className="text-yellow-300"
  >
    <path d="M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z"/>
    <path d="m12 10-2 5h4l-2 5"/>
  </svg>
);

export default HUD;