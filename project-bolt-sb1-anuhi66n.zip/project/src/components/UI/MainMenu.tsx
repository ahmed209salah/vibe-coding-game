import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Plane, Cloud, Zap, Settings, Trophy, Info, Github } from 'lucide-react';
import { useGame } from '../../contexts/GameContext';
import { playSound } from '../../utils/audio';

interface MainMenuProps {
  onStartGame: () => void;
}

const MainMenu: React.FC<MainMenuProps> = ({ onStartGame }) => {
  const [activeSection, setActiveSection] = useState<string | null>(null);
  const { setAircraftType, aircraftType } = useGame();
  
  const handleStartGame = () => {
    playSound('button');
    onStartGame();
  };
  
  const handleShowSection = (section: string) => {
    playSound('button');
    setActiveSection(section === activeSection ? null : section);
  };
  
  const handleSelectAircraft = (type: string) => {
    playSound('button');
    setAircraftType(type);
  };
  
  return (
    <div className="relative h-full w-full flex items-center justify-center bg-gradient-to-b from-slate-900 to-slate-800 overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        {Array.from({ length: 20 }).map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-blue-500 rounded-full"
            initial={{ 
              x: Math.random() * window.innerWidth, 
              y: Math.random() * window.innerHeight, 
              opacity: Math.random() * 0.7
            }}
            animate={{ 
              y: [null, Math.random() * 200 - 100 + '%'],
              opacity: [null, Math.random() * 0.5 + 0.2]
            }}
            transition={{ 
              duration: Math.random() * 10 + 15, 
              repeat: Infinity, 
              repeatType: 'reverse'
            }}
          />
        ))}
      </div>
      
      <motion.div 
        className="relative z-10 glass-panel p-8 rounded-xl max-w-4xl w-full mx-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="text-center mb-10">
          <motion.div 
            className="flex items-center justify-center gap-3 mb-2"
            initial={{ scale: 0.9 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <Plane className="text-blue-400" size={32} />
            <h1 className="text-5xl font-bold text-white aircraft-panel">SKY COMMAND</h1>
            <Plane className="text-blue-400 transform rotate-180" size={32} />
          </motion.div>
          <p className="text-blue-200 text-xl">The ultimate flight simulator experience</p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <motion.button
            className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white py-4 px-6 rounded-lg text-xl font-bold shadow-lg hover:from-blue-500 hover:to-indigo-600 transition-all flex items-center justify-center gap-2"
            onClick={handleStartGame}
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.98 }}
          >
            <Zap size={20} />
            Start Flying
          </motion.button>
          
          <motion.button
            className="bg-gradient-to-r from-slate-700 to-slate-800 text-white py-4 px-6 rounded-lg text-xl font-bold shadow-lg hover:from-slate-600 hover:to-slate-700 transition-all flex items-center justify-center gap-2"
            onClick={() => handleShowSection('aircraft')}
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.98 }}
          >
            <Plane size={20} />
            Select Aircraft
          </motion.button>
        </div>
        
        {activeSection === 'aircraft' && (
          <motion.div 
            className="mb-8 bg-slate-800 p-6 rounded-lg"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
          >
            <h2 className="text-2xl font-bold text-white mb-4">Select Your Aircraft</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <AircraftOption 
                name="Fighter Jet"
                type="fighter"
                description="Fast & agile. Perfect for stunts."
                isSelected={aircraftType === 'fighter'}
                onSelect={handleSelectAircraft}
              />
              <AircraftOption 
                name="Commercial Airliner"
                type="airliner"
                description="Stable & spacious. Great for cruising."
                isSelected={aircraftType === 'airliner'}
                onSelect={handleSelectAircraft}
              />
              <AircraftOption 
                name="Propeller Plane"
                type="propeller"
                description="Classic & responsive. Easy to control."
                isSelected={aircraftType === 'propeller'}
                onSelect={handleSelectAircraft}
              />
            </div>
          </motion.div>
        )}
        
        <div className="grid grid-cols-3 gap-4">
          <MenuButton icon={<Settings size={18} />} label="Settings" onClick={() => handleShowSection('settings')} />
          <MenuButton icon={<Trophy size={18} />} label="Achievements" onClick={() => handleShowSection('achievements')} />
          <MenuButton icon={<Info size={18} />} label="Tutorial" onClick={() => handleShowSection('tutorial')} />
        </div>
        
        <div className="mt-8 text-center text-slate-400 text-sm">
          <p>© 2025 Sky Command Studios. All rights reserved.</p>
          <div className="flex items-center justify-center gap-2 mt-2">
            <a href="#" className="text-slate-400 hover:text-white transition-colors">
              <Github size={16} />
            </a>
          </div>
        </div>
      </motion.div>
      
      {/* Floating clouds in background */}
      <motion.div
        className="absolute bottom-10 right-10 text-slate-700 opacity-20"
        initial={{ y: 0 }}
        animate={{ y: [-10, 10, -10] }}
        transition={{ duration: 6, repeat: Infinity }}
      >
        <Cloud size={120} />
      </motion.div>
      
      <motion.div
        className="absolute top-20 left-10 text-slate-700 opacity-10"
        initial={{ y: 0 }}
        animate={{ y: [10, -10, 10] }}
        transition={{ duration: 8, repeat: Infinity }}
      >
        <Cloud size={80} />
      </motion.div>
    </div>
  );
};

interface AircraftOptionProps {
  name: string;
  type: string;
  description: string;
  isSelected: boolean;
  onSelect: (type: string) => void;
}

const AircraftOption: React.FC<AircraftOptionProps> = ({ 
  name, type, description, isSelected, onSelect
}) => {
  return (
    <motion.div 
      className={`p-4 rounded-lg cursor-pointer transition-all ${
        isSelected ? 'bg-blue-600' : 'bg-slate-700 hover:bg-slate-600'
      }`}
      onClick={() => onSelect(type)}
      whileHover={{ scale: 1.03 }}
      whileTap={{ scale: 0.98 }}
    >
      <div className="flex items-center mb-2">
        <Plane size={20} className={isSelected ? 'text-white' : 'text-blue-400'} />
        <h3 className="text-lg font-bold text-white ml-2">{name}</h3>
      </div>
      <p className={`text-sm ${isSelected ? 'text-blue-100' : 'text-slate-300'}`}>
        {description}
      </p>
    </motion.div>
  );
};

interface MenuButtonProps {
  icon: React.ReactNode;
  label: string;
  onClick: () => void;
}

const MenuButton: React.FC<MenuButtonProps> = ({ icon, label, onClick }) => {
  return (
    <motion.button
      className="flex flex-col items-center justify-center bg-slate-800 hover:bg-slate-700 p-4 rounded-lg transition-colors"
      onClick={onClick}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
    >
      <div className="text-blue-400 mb-1">{icon}</div>
      <span className="text-white text-sm">{label}</span>
    </motion.button>
  );
};

export default MainMenu;