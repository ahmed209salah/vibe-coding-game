import React from 'react';
import { Loader } from 'lucide-react';
import { useGame } from '../../contexts/GameContext';

const LoadingScreen: React.FC = () => {
  const { isLoading, loadingProgress } = useGame();

  if (!isLoading) return null;

  return (
    <div className="absolute inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
      <div className="text-center">
        <Loader className="w-12 h-12 text-blue-500 animate-spin mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-white mb-2">Loading Game</h2>
        <p className="text-gray-300 mb-4">Please wait while we prepare your flight...</p>
        <div className="w-64 h-2 bg-gray-700 rounded-full overflow-hidden">
          <div 
            className="h-full bg-blue-500 transition-all duration-300"
            style={{ width: `${loadingProgress}%` }}
          />
        </div>
        <p className="text-blue-400 mt-2">{Math.round(loadingProgress)}%</p>
      </div>
    </div>
  );
};

export default LoadingScreen;