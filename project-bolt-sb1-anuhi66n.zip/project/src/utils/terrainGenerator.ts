import * as THREE from 'three';

// Generate a random terrain heightmap
export const generateTerrain = (width: number, height: number, size: number, maxHeight: number) => {
  // Create a heightmap using Perlin-like noise
  const heightMap = new THREE.DataTexture(
    new Float32Array(width * height),
    width,
    height,
    THREE.RedFormat,
    THREE.FloatType
  );
  
  // Generate terrain data using multiple octaves of noise
  const data = heightMap.image.data;
  const perlinNoise = (x: number, y: number, scale = 1, octaves = 6, persistence = 0.5) => {
    let total = 0;
    let frequency = scale;
    let amplitude = 1;
    let maxValue = 0;
    
    for (let i = 0; i < octaves; i++) {
      // Simple value noise as a placeholder for Perlin noise
      const noise = Math.sin(x * frequency) * Math.sin(y * frequency);
      total += noise * amplitude;
      
      maxValue += amplitude;
      amplitude *= persistence;
      frequency *= 2;
    }
    
    return total / maxValue;
  };
  
  // Fill the heightmap with terrain data
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      // Generate base terrain
      const i = y * width + x;
      const nx = x / width - 0.5;
      const ny = y / height - 0.5;
      
      // Generate value using multiple frequencies
      let value = perlinNoise(nx * 5, ny * 5, 1.0);
      
      // Add some randomness
      value += (Math.random() * 2 - 1) * 0.02;
      
      // Create continents and oceans
      const distance = Math.sqrt(nx * nx + ny * ny) * 2;
      value -= Math.pow(distance, 2) * 0.5;
      
      // Scale to the desired height range
      value = Math.max(0, value);
      value = Math.pow(value, 1.5) * maxHeight;
      
      data[i] = value;
    }
  }
  
  heightMap.needsUpdate = true;
  
  // Create the plane geometry for the terrain
  const geometry = new THREE.PlaneGeometry(size, size, width - 1, height - 1);
  
  // Update vertices based on the heightmap
  const vertices = geometry.attributes.position.array;
  for (let i = 0; i < vertices.length; i += 3) {
    const x = (i / 3) % width;
    const y = Math.floor((i / 3) / width);
    if (x < width && y < height) {
      const index = y * width + x;
      vertices[i + 2] = data[index];
    }
  }
  
  geometry.computeVertexNormals();
  
  return { geometry, heightMap };
};

// Generate 3D objects for the environment
export const generateEnvironmentObjects = (
  count: number,
  size: number,
  heightMap: THREE.DataTexture,
  mapSize: number
) => {
  const objects: { position: THREE.Vector3; scale: THREE.Vector3; type: string }[] = [];
  
  // Tree positions
  for (let i = 0; i < count; i++) {
    // Random position within the terrain
    const x = (Math.random() - 0.5) * size;
    const z = (Math.random() - 0.5) * size;
    
    // Map position to heightmap coordinates
    const mapX = Math.floor(((x / size) + 0.5) * mapSize);
    const mapY = Math.floor(((z / size) + 0.5) * mapSize);
    
    if (mapX >= 0 && mapX < mapSize && mapY >= 0 && mapY < mapSize) {
      // Get height at this position
      const heightIndex = mapY * mapSize + mapX;
      const height = heightMap.image.data[heightIndex];
      
      // Only place objects above water level and below snow line
      if (height > 10 && height < 150) {
        const objectType = height > 80 ? 'rock' : 'tree';
        const scale = new THREE.Vector3(
          1 + Math.random() * 0.5,
          1 + Math.random() * 1.0,
          1 + Math.random() * 0.5
        );
        
        objects.push({
          position: new THREE.Vector3(x, height, z),
          scale,
          type: objectType,
        });
      }
    }
  }
  
  return objects;
};