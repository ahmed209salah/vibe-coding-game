import { Howl } from 'howler';

interface SoundOptions {
  volume?: number;
  loop?: boolean;
  rate?: number;
}

const sounds: Record<string, Howl> = {
  engine: new Howl({
    src: ['https://cdn.freesound.org/previews/115/115612_2137497-lq.mp3'],
    html5: true,
    volume: 0.5,
    loop: true,
  }),
  wind: new Howl({
    src: ['https://cdn.freesound.org/previews/157/157744_2271655-lq.mp3'],
    html5: true,
    volume: 0.3,
    loop: true,
  }),
  collision: new Howl({
    src: ['https://cdn.freesound.org/previews/131/131143_2283624-lq.mp3'],
    html5: true,
    volume: 0.8,
  }),
  gameStart: new Howl({
    src: ['https://cdn.freesound.org/previews/352/352661_5121236-lq.mp3'],
    html5: true,
    volume: 0.6,
  }),
  gameOver: new Howl({
    src: ['https://cdn.freesound.org/previews/76/76376_1389015-lq.mp3'],
    html5: true,
    volume: 0.7,
  }),
  button: new Howl({
    src: ['https://cdn.freesound.org/previews/242/242501_4414128-lq.mp3'],
    html5: true,
    volume: 0.5,
  }),
  achievement: new Howl({
    src: ['https://cdn.freesound.org/previews/320/320775_5260872-lq.mp3'],
    html5: true,
    volume: 0.6,
  }),
};

export const playSound = (
  id: keyof typeof sounds,
  options: SoundOptions = {}
): string => {
  if (!sounds[id]) {
    console.error(`Sound with id "${id}" not found`);
    return '';
  }
  
  const { volume, loop, rate } = options;
  
  if (volume !== undefined) {
    sounds[id].volume(volume);
  }
  
  if (loop !== undefined) {
    sounds[id].loop(loop);
  }
  
  if (rate !== undefined) {
    sounds[id].rate(rate);
  }
  
  const soundId = sounds[id].play();
  return soundId.toString();
};

export const stopSound = (id: keyof typeof sounds): void => {
  if (!sounds[id]) {
    console.error(`Sound with id "${id}" not found`);
    return;
  }
  
  sounds[id].stop();
};

export const pauseSound = (id: keyof typeof sounds): void => {
  if (!sounds[id]) {
    console.error(`Sound with id "${id}" not found`);
    return;
  }
  
  sounds[id].pause();
};

export const updateSoundVolume = (id: keyof typeof sounds, volume: number): void => {
  if (!sounds[id]) {
    console.error(`Sound with id "${id}" not found`);
    return;
  }
  
  sounds[id].volume(Math.max(0, Math.min(1, volume)));
};

export const updateSoundRate = (id: keyof typeof sounds, rate: number): void => {
  if (!sounds[id]) {
    console.error(`Sound with id "${id}" not found`);
    return;
  }
  
  sounds[id].rate(Math.max(0.5, Math.min(4, rate)));
};